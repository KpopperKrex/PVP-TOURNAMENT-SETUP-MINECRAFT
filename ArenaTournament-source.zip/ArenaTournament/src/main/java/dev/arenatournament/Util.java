package dev.arenatournament;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

final class Util {
    private static final LegacyComponentSerializer LS = LegacyComponentSerializer.legacyAmpersand();
    private Util() {}

    static Component c(String s) {
        return LS.deserialize(s == null ? "" : s).decorationIfAbsent(TextDecoration.ITALIC, TextDecoration.State.FALSE);
    }
    static String plain(String legacy) { return PlainTextComponentSerializer.plainText().serialize(c(legacy)); }

    static ItemStack item(Material m, String name, String... lore) {
        ItemStack it = new ItemStack(m);
        ItemMeta meta = it.getItemMeta();
        meta.displayName(c(name));
        if (lore.length > 0) { List<Component> l = new ArrayList<>(); for (String s : lore) l.add(c(s)); meta.lore(l); }
        it.setItemMeta(meta);
        return it;
    }
    static ItemStack item(Material m, String name, List<String> lore) { return item(m, name, lore.toArray(new String[0])); }

    static Map<String, Object> ser(Location l) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("x", l.getX()); m.put("y", l.getY()); m.put("z", l.getZ()); m.put("yaw", (double) l.getYaw()); m.put("pitch", (double) l.getPitch());
        return m;
    }
    static Location loc(org.bukkit.World w, ConfigurationSection s) {
        if (s == null || w == null) return null;
        return new Location(w, s.getDouble("x"), s.getDouble("y"), s.getDouble("z"), (float) s.getDouble("yaw"), (float) s.getDouble("pitch"));
    }
}
