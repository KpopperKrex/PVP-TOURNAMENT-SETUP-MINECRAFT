package dev.arenatournament;

import org.bukkit.*;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.BoundingBox;
import org.bukkit.util.Transformation;
import org.joml.AxisAngle4f;
import org.joml.Vector3f;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Procedurally builds the lobby, 8 arenas, stadium, spectator hub and podium in a void world,
 * spread over many ticks, then writes arenas.yml. All arenas share identical dimensions and layout.
 */
class WorldBuilder {
    private record Fill(int x1, int y1, int z1, int x2, int y2, int z2, Material m) {}
    private record Theme(String name, Material floor, Material wall, Material accent, Material pillar, Material light) {}

    static final int Y = 100, ARENA_Z = 150, STADIUM_Z = 330;
    static final int HALF = 20;

    private final ArenaTournamentPlugin pl;
    private final ArrayDeque<Fill> queue = new ArrayDeque<>();
    private World world;
    private boolean building;
    private int total;

    private static final Theme[] THEMES = {
            new Theme("Medieval Colosseum", Material.STONE_BRICKS, Material.STONE_BRICKS, Material.CHISELED_STONE_BRICKS, Material.COBBLESTONE, Material.GLOWSTONE),
            new Theme("Nether Fortress", Material.NETHER_BRICKS, Material.NETHER_BRICKS, Material.RED_NETHER_BRICKS, Material.CHISELED_NETHER_BRICKS, Material.SHROOMLIGHT),
            new Theme("Frozen Kingdom", Material.SNOW_BLOCK, Material.PACKED_ICE, Material.BLUE_ICE, Material.QUARTZ_PILLAR, Material.SEA_LANTERN),
            new Theme("Japanese Temple", Material.DARK_OAK_PLANKS, Material.RED_CONCRETE, Material.STRIPPED_CRIMSON_STEM, Material.CRIMSON_PLANKS, Material.OCHRE_FROGLIGHT),
            new Theme("Desert Ruins", Material.SMOOTH_SANDSTONE, Material.CUT_SANDSTONE, Material.CHISELED_SANDSTONE, Material.SANDSTONE, Material.GLOWSTONE),
            new Theme("Ancient Jungle", Material.MOSSY_STONE_BRICKS, Material.MOSSY_COBBLESTONE, Material.JUNGLE_LOG, Material.JUNGLE_LOG, Material.VERDANT_FROGLIGHT),
            new Theme("End Dimension", Material.END_STONE_BRICKS, Material.PURPUR_BLOCK, Material.PURPUR_PILLAR, Material.PURPUR_PILLAR, Material.PEARLESCENT_FROGLIGHT),
            new Theme("Royal Castle", Material.POLISHED_ANDESITE, Material.STONE_BRICKS, Material.GOLD_BLOCK, Material.QUARTZ_PILLAR, Material.SEA_LANTERN),
    };

    WorldBuilder(ArenaTournamentPlugin pl) { this.pl = pl; }

    boolean isBuilding() { return building; }

    // ---------- primitives ----------
    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material m) {
        queue.add(new Fill(Math.min(x1, x2), Math.min(y1, y2), Math.min(z1, z2), Math.max(x1, x2), Math.max(y1, y2), Math.max(z1, z2), m));
    }
    private void disk(int cx, int y, int cz, int r, Material m) {
        for (int dx = -r; dx <= r; dx++) { int dz = (int) Math.floor(Math.sqrt((double) r * r - (double) dx * dx)); fill(cx + dx, y, cz - dz, cx + dx, y, cz + dz, m); }
    }
    private void perimeter(int cx, int cz, int r, int y1, int y2, Material m) {
        fill(cx - r, y1, cz - r, cx + r, y2, cz - r, m); fill(cx - r, y1, cz + r, cx + r, y2, cz + r, m);
        fill(cx - r, y1, cz - r + 1, cx - r, y2, cz + r - 1, m); fill(cx + r, y1, cz - r + 1, cx + r, y2, cz + r - 1, m);
    }

    // ---------- structures ----------
    private void lobby() {
        disk(0, Y, 0, 26, Material.POLISHED_BLACKSTONE_BRICKS);
        disk(0, Y, 0, 24, Material.QUARTZ_BLOCK);
        disk(0, Y, 0, 8, Material.POLISHED_ANDESITE);
        disk(0, Y, 0, 5, Material.GOLD_BLOCK);
        disk(0, Y, 0, 3, Material.SEA_LANTERN);
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            fill(sx * 18 - 1, Y + 1, sz * 18 - 1, sx * 18 + 1, Y + 8, sz * 18 + 1, Material.QUARTZ_PILLAR);
            fill(sx * 18, Y + 9, sz * 18, sx * 18, Y + 9, sz * 18, Material.SEA_LANTERN);
        }
        // entrance arch (north side) and registration pad
        fill(-4, Y + 1, -25, -3, Y + 9, -25, Material.POLISHED_BLACKSTONE_BRICKS);
        fill(3, Y + 1, -25, 4, Y + 9, -25, Material.POLISHED_BLACKSTONE_BRICKS);
        fill(-4, Y + 10, -25, 4, Y + 11, -25, Material.GOLD_BLOCK);
        fill(-14, Y + 1, -10, -10, Y + 1, -6, Material.GOLD_BLOCK);
        fill(10, Y + 1, -10, 14, Y + 1, -6, Material.LAPIS_BLOCK);
    }

    private void hub() {
        disk(0, Y, -90, 16, Material.DEEPSLATE_TILES);
        disk(0, Y, -90, 13, Material.POLISHED_DEEPSLATE);
        disk(0, Y, -90, 4, Material.SEA_LANTERN);
        for (int a = 0; a < 4; a++) {
            int x = (a % 2 == 0 ? -1 : 1) * 12, z = -90 + (a < 2 ? -1 : 1) * 12;
            fill(x, Y + 1, z, x, Y + 6, z, Material.POLISHED_DEEPSLATE); fill(x, Y + 7, z, x, Y + 7, z, Material.SEA_LANTERN);
        }
    }

    private void arena(int i, Theme t) {
        int cx = -210 + 60 * i, cz = ARENA_Z;
        fill(cx - HALF, Y, cz - HALF, cx + HALF, Y, cz + HALF, t.floor());
        perimeter(cx, cz, HALF, Y + 1, Y + 8, t.wall());
        // corner towers
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            fill(cx + sx * 20 - 1, Y + 1, cz + sz * 20 - 1, cx + sx * 20 + 1, Y + 12, cz + sz * 20 + 1, t.accent());
            fill(cx + sx * 20, Y + 13, cz + sz * 20, cx + sx * 20, Y + 13, cz + sz * 20, t.light());
        }
        // symmetric cover: four 2x2 pillars + low centre block
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            int px = cx + (sx > 0 ? 7 : -8), pz = cz + (sz > 0 ? 7 : -8);
            fill(px, Y + 1, pz, px + 1, Y + 4, pz + 1, t.pillar());
        }
        fill(cx - 1, Y + 1, cz - 1, cx + 1, Y + 1, cz + 1, t.accent());
        // wall lights
        for (int o : new int[]{-15, -5, 5, 15}) {
            fill(cx + o, Y + 5, cz - HALF, cx + o, Y + 5, cz - HALF, t.light()); fill(cx + o, Y + 5, cz + HALF, cx + o, Y + 5, cz + HALF, t.light());
            fill(cx - HALF, Y + 5, cz + o, cx - HALF, Y + 5, cz + o, t.light()); fill(cx + HALF, Y + 5, cz + o, cx + HALF, Y + 5, cz + o, t.light());
        }
        // spectator deck outside the north wall
        fill(cx - 4, Y + 11, cz - 27, cx + 4, Y + 11, cz - 23, t.accent());
    }

    private void stadium() {
        int cx = 0, cz = STADIUM_Z, R = 24;
        fill(cx - R, Y, cz - R, cx + R, Y, cz + R, Material.SMOOTH_QUARTZ);
        fill(cx - 3, Y, cz - 3, cx + 3, Y, cz + 3, Material.GOLD_BLOCK);
        perimeter(cx, cz, R + 1, Y + 1, Y + 3, Material.GLASS);
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            int px = cx + (sx > 0 ? 8 : -9), pz = cz + (sz > 0 ? 8 : -9);
            fill(px, Y + 1, pz, px + 1, Y + 3, pz + 1, Material.QUARTZ_PILLAR);
        }
        for (int k = 0; k < 8; k++) {
            Material m = k % 2 == 0 ? Material.QUARTZ_BRICKS : Material.SMOOTH_QUARTZ;
            perimeter(cx, cz, 26 + 2 * k, Y, Y + 1 + k, m);
            perimeter(cx, cz, 27 + 2 * k, Y, Y + 1 + k, m);
        }
        for (int sx : new int[]{-1, 1}) for (int sz : new int[]{-1, 1}) {
            fill(sx * 46 - 1, Y, STADIUM_Z + sz * 46 - 1, sx * 46 + 1, Y + 26, STADIUM_Z + sz * 46 + 1, Material.QUARTZ_PILLAR);
            fill(sx * 46, Y + 27, STADIUM_Z + sz * 46, sx * 46, Y + 27, STADIUM_Z + sz * 46, Material.SEA_LANTERN);
        }
        // champion celebration platform
        int pz = 440;
        disk(0, Y, pz, 12, Material.GOLD_BLOCK);
        disk(0, Y, pz, 10, Material.POLISHED_ANDESITE);
        fill(-1, Y + 1, pz - 1, 1, Y + 2, pz + 1, Material.GOLD_BLOCK);   // 1st
        fill(-4, Y + 1, pz - 1, -3, Y + 1, pz + 1, Material.IRON_BLOCK);  // 2nd
        fill(3, Y + 1, pz - 1, 4, Y + 1, pz + 1, Material.COPPER_BLOCK);   // 3rd
    }

    private void text(String tag, double x, double y, double z, String text, float scale) {
        Location l = new Location(world, x, y, z);
        world.spawn(l, TextDisplay.class, d -> {
            d.text(Util.c(text));
            d.setBillboard(Display.Billboard.CENTER);
            d.setLineWidth(300);
            d.setPersistent(true);
            d.addScoreboardTag(tag);
            d.setTransformation(new Transformation(new Vector3f(), new AxisAngle4f(), new Vector3f(scale, scale, scale), new AxisAngle4f()));
        });
    }

    // ---------- build ----------
    void build(CommandSender who) {
        if (building) { who.sendMessage(Util.c("&cA build is already running.")); return; }
        world = ArenaManager.ensureWorld(pl.settings.str("world.name", "TournamentWorld"));
        if (world == null) { who.sendMessage(Util.c("&cCould not create the world.")); return; }
        building = true; queue.clear();
        lobby(); hub();
        for (int i = 0; i < 8; i++) arena(i, THEMES[i]);
        stadium();
        total = queue.size();
        who.sendMessage(Util.c("&eBuilding tournament world (" + total + " fill operations)... this takes a short while."));
        new BukkitRunnable() {
            Fill cur; int x, y, z, tick;
            @Override public void run() {
                int budget = 14000;
                while (budget > 0) {
                    if (cur == null) {
                        cur = queue.poll();
                        if (cur == null) { cancel(); finish(who); return; }
                        x = cur.x1(); y = cur.y1(); z = cur.z1();
                    }
                    world.getBlockAt(x, y, z).setType(cur.m(), false);
                    budget--;
                    if (++x > cur.x2()) { x = cur.x1(); if (++z > cur.z2()) { z = cur.z1(); if (++y > cur.y2()) cur = null; } }
                }
                if (++tick % 40 == 0) who.sendMessage(Util.c("&7Building... " + (100 - queue.size() * 100 / Math.max(1, total)) + "%"));
            }
        }.runTaskTimer(pl, 1L, 1L);
    }

    private void finish(CommandSender who) {
        try {
            // remove old decorations, then place labels
            for (Entity e : world.getEntities()) if (e instanceof TextDisplay d && d.getScoreboardTags().stream().anyMatch(s -> s.startsWith("at_"))) d.remove();
            text("at_deco", 0.5, Y + 12, -25.5, "&6&l%s\n&fWelcome to the tournament!".formatted(pl.settings.tname()), 2.5f);
            text("at_status", 0.5, Y + 4, 14.5, "&eStatus loading...", 1.6f);
            text("at_register", -12, Y + 3, -8, "&6&lREGISTRATION\n&f/at join &7- enter\n&f/at leave &7- withdraw", 1.4f);
            text("at_bracket", 12, Y + 3, -8, "&b&lBRACKET\n&f/at bracket", 1.4f);
            text("at_hub", 0.5, Y + 5, -80.5, "&bSPECTATOR HUB", 1.8f);
            text("at_deco", 0.5, Y + 3, -88.5, "&f/at spectate &7- watch live matches\n&f/at leave &7- exit", 1.3f);
            for (int i = 0; i < 8; i++) text("at_deco", -210 + 60 * i + 0.5, Y + 15, ARENA_Z - 24.5, "&e&lARENA " + (i + 1) + "\n&7" + THEMES[i].name(), 2f);
            text("at_deco", 0.5, Y + 40, STADIUM_Z - 48, "&6&lGRAND FINAL STADIUM\n&f" + pl.settings.tname(), 5f);
            text("at_deco", 0.5, Y + 6, 440.5, "&6&lCHAMPION", 3f);

            YamlConfiguration y = new YamlConfiguration();
            y.set("world", world.getName());
            y.set("lobby", Util.ser(new Location(world, 0.5, Y + 1, 0.5, 0, 0)));
            y.set("hub", Util.ser(new Location(world, 0.5, Y + 2, -90.5, 0, 0)));
            y.set("podium", Util.ser(new Location(world, 0.5, Y + 3, 440.5, 180, 0)));
            for (int i = 0; i < 8; i++) {
                int cx = -210 + 60 * i, cz = ARENA_Z;
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("name", "Arena " + (i + 1)); m.put("theme", THEMES[i].name()); m.put("enabled", true);
                m.put("spawn1", Util.ser(new Location(world, cx - 14 + 0.5, Y + 1, cz + 0.5, -90, 0)));
                m.put("spawn2", Util.ser(new Location(world, cx + 14 + 0.5, Y + 1, cz + 0.5, 90, 0)));
                m.put("spectate", Util.ser(new Location(world, cx + 0.5, Y + 12, cz - 24.5, 0, 35)));
                m.put("min", Map.of("x", (double) cx - HALF, "y", (double) Y, "z", (double) cz - HALF));
                m.put("max", Map.of("x", (double) cx + HALF + 1, "y", (double) Y + 40, "z", (double) cz + HALF + 1));
                y.set("arenas." + (i + 1), m);
            }
            Map<String, Object> s = new LinkedHashMap<>();
            s.put("name", "Grand Stadium"); s.put("theme", "Stadium"); s.put("enabled", true);
            s.put("spawn1", Util.ser(new Location(world, -16 + 0.5, Y + 1, STADIUM_Z + 0.5, -90, 0)));
            s.put("spawn2", Util.ser(new Location(world, 16 + 0.5, Y + 1, STADIUM_Z + 0.5, 90, 0)));
            s.put("spectate", Util.ser(new Location(world, 0.5, Y + 8, STADIUM_Z - 33.5, 0, 25)));
            s.put("min", Map.of("x", -24.0, "y", (double) Y, "z", (double) STADIUM_Z - 24));
            s.put("max", Map.of("x", 25.0, "y", (double) Y + 40, "z", (double) STADIUM_Z + 25));
            y.set("stadium", s);
            y.save(pl.arenas.file());
            world.setSpawnLocation(0, Y + 1, 0);
            world.setTime(6000);
            pl.arenas.load();
            if (pl.getServer().getPluginManager().getPlugin("WorldGuard") != null)
                who.sendMessage(Util.c("&7WorldGuard detected - run &e/at setup worldguard &7to create protection regions."));
            who.sendMessage(Util.c("&aTournament world built and arenas registered. Run &e/at validate&a to verify."));
        } catch (IOException e) {
            who.sendMessage(Util.c("&cBuild finished but arenas.yml could not be written: " + e.getMessage()));
        } finally { building = false; }
    }
}
