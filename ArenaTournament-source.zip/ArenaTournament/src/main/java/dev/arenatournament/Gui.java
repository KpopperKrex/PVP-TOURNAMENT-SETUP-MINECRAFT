package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;

class Gui implements InventoryHolder {
    final Inventory inv;
    final Map<Integer, Consumer<InventoryClickEvent>> actions = new HashMap<>();
    Runnable refresher;
    final int size;

    Gui(String title, int rows) { size = rows * 9; inv = Bukkit.createInventory(this, size, Util.c(title)); }

    void clear() { inv.clear(); actions.clear(); }
    void set(int slot, ItemStack it, Consumer<InventoryClickEvent> a) {
        if (slot < 0 || slot >= size) return;
        inv.setItem(slot, it);
        if (a != null) actions.put(slot, a); else actions.remove(slot);
    }
    void open(Player p) { p.openInventory(inv); }
    @Override public Inventory getInventory() { return inv; }
}
