package dev.arenatournament;

import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.block.Block;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;

import java.time.Duration;
import java.util.*;

/** Runs the live matches: countdown, kits, results, disconnects, timeouts and arena cleanup. */
class MatchManager {
    static class Active {
        final BracketMatch bm;
        final Arena arena;
        int countdown, timeLeft;
        boolean ended;
        final Map<UUID, Integer> grace = new HashMap<>();
        final Set<Block> placed = new HashSet<>();
        Active(BracketMatch bm, Arena arena) { this.bm = bm; this.arena = arena; }
    }

    private final ArenaTournamentPlugin pl;
    final Map<Integer, Active> byMatch = new LinkedHashMap<>();
    final Map<UUID, Active> byPlayer = new HashMap<>();
    final Set<UUID> frozen = new HashSet<>();

    MatchManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    Active of(UUID u) { return byPlayer.get(u); }
    Active ofMatch(int id) { return byMatch.get(id); }
    int running() { return byMatch.size(); }

    // ---------- start ----------
    boolean start(BracketMatch bm, Arena arena) {
        Tournament t = pl.tournaments.t;
        if (t == null || bm.p[0] == null || bm.p[1] == null || bm.p[0].equals(bm.p[1]) || bm.done()) return false;
        if (t.eliminated.contains(bm.p[0]) || t.eliminated.contains(bm.p[1])) return false;
        Player a = Bukkit.getPlayer(bm.p[0]), b = Bukkit.getPlayer(bm.p[1]);
        if (a == null || b == null) return false;
        if (byPlayer.containsKey(a.getUniqueId()) || byPlayer.containsKey(b.getUniqueId()) || byMatch.containsKey(bm.id)) return false;
        String prob = arena.problem();
        if (prob != null) { pl.arenas.reportProblem(arena, prob); return false; }

        Active am = new Active(bm, arena);
        am.countdown = Math.max(1, pl.settings.num("matches.countdown-seconds", 10));
        arena.occupiedBy = bm.id; bm.arenaId = arena.id; bm.state = MState.COUNTDOWN;
        byMatch.put(bm.id, am); byPlayer.put(a.getUniqueId(), am); byPlayer.put(b.getUniqueId(), am);
        pl.spectators.forget(a); pl.spectators.forget(b);
        prepare(a, arena.spawn1); prepare(b, arena.spawn2);
        pl.settings.bcastRaw("match-announce", "%arena%", arena.label(), "%p1%", a.getName(), "%p2%", b.getName());
        pl.tournaments.changed();
        return true;
    }

    private void prepare(Player p, Location spawn) {
        pl.states.ensureSaved(p);
        p.setGameMode(GameMode.SURVIVAL);
        p.setAllowFlight(false); p.setFlying(false);
        p.closeInventory();
        p.getInventory().clear();
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
        p.setHealth(Math.min(max, Math.max(1, pl.settings.num("combat.health", 20))));
        p.setFoodLevel(pl.settings.num("combat.food", 20));
        p.setSaturation(20f); p.setExp(0); p.setLevel(0); p.setFireTicks(0); p.setFallDistance(0);
        pl.kits.apply(p);
        p.teleport(spawn);
        frozen.add(p.getUniqueId());
    }

    // ---------- 1-second tick ----------
    void tick() {
        for (Active am : new ArrayList<>(byMatch.values())) {
            if (am.ended) continue;
            UUID expired = null;
            for (Iterator<Map.Entry<UUID, Integer>> it = am.grace.entrySet().iterator(); it.hasNext(); ) {
                Map.Entry<UUID, Integer> e = it.next();
                e.setValue(e.getValue() - 1);
                if (e.getValue() <= 0) { expired = e.getKey(); it.remove(); break; }
            }
            if (expired != null) { disconnectExpired(am, expired); continue; }
            if (am.bm.state == MState.COUNTDOWN) {
                if (am.countdown > 0) { countdownTitle(am); am.countdown--; } else begin(am);
            } else if (am.bm.state == MState.RUNNING && am.timeLeft > 0) {
                am.timeLeft--;
                if (am.timeLeft <= 0) timeout(am);
                else if (am.timeLeft <= 10 || am.timeLeft % 60 == 0) for (UUID u : am.bm.p) { Player p = Bukkit.getPlayer(u); if (p != null) p.sendActionBar(Util.c("&eTime left: &f" + am.timeLeft + "s")); }
            }
        }
    }

    private void countdownTitle(Active am) {
        for (UUID u : am.bm.p) {
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            p.showTitle(Title.title(Util.c((am.countdown <= 3 ? "&c&l" : "&e&l") + am.countdown), Util.c("&7vs &f" + pl.tournaments.t.nameOf(am.bm.other(u))),
                    Title.Times.times(Duration.ZERO, Duration.ofMillis(1100), Duration.ZERO)));
            if (am.countdown <= 5) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1f);
        }
    }

    private void begin(Active am) {
        am.bm.state = MState.RUNNING;
        am.timeLeft = pl.settings.num("matches.timeout-seconds", 300);
        for (UUID u : am.bm.p) {
            frozen.remove(u);
            Player p = Bukkit.getPlayer(u);
            if (p == null) continue;
            p.showTitle(Title.title(Util.c("&a&lFIGHT!"), Util.c(""), Title.Times.times(Duration.ZERO, Duration.ofMillis(900), Duration.ofMillis(200))));
            p.playSound(p.getLocation(), Sound.ENTITY_ENDER_DRAGON_GROWL, 0.6f, 1.2f);
        }
        pl.tournaments.changed();
    }

    private void timeout(Active am) {
        Player a = Bukkit.getPlayer(am.bm.p[0]), b = Bukkit.getPlayer(am.bm.p[1]);
        double ha = a == null ? -1 : a.getHealth(), hb = b == null ? -1 : b.getHealth();
        UUID w = ha > hb ? am.bm.p[0] : hb > ha ? am.bm.p[1] : am.bm.p[new Random().nextInt(2)];
        finish(am, w, am.bm.other(w), ha == hb ? "TIMEOUT (coin flip)" : "TIMEOUT (health)", false);
    }

    // ---------- results ----------
    void death(Active am, Player victim) {
        if (am.ended || am.bm.state != MState.RUNNING) return;
        UUID v = victim.getUniqueId();
        finish(am, am.bm.other(v), v, "KILL", false);
    }

    /** Single entry point for every result. Guarded so a match can only ever be resolved once. */
    void finish(Active am, UUID winner, UUID loser, String reason, boolean forfeit) {
        if (am.ended) return;
        if (winner == null || loser == null || winner.equals(loser) || !am.bm.has(winner) || !am.bm.has(loser)) return;
        am.ended = true;
        Player lp = Bukkit.getPlayer(loser), wp = Bukkit.getPlayer(winner);
        if (lp != null) {
            lp.setGameMode(GameMode.SPECTATOR);
            lp.showTitle(Title.title(Util.c("&c&lDEFEATED"), Util.c("&7Better luck next time")));
        }
        if (wp != null) {
            wp.showTitle(Title.title(Util.c("&a&lVICTORY"), Util.c("&7You advance!")));
            wp.playSound(wp.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1f);
        }
        frozen.remove(winner); frozen.remove(loser);
        pl.tournaments.matchFinished(am.bm, winner, loser, reason, forfeit);
        long delay = Math.max(1, pl.settings.num("matches.post-match-seconds", 4)) * 20L;
        Bukkit.getScheduler().runTaskLater(pl, () -> reset(am), delay);
    }

    private void reset(Active am) {
        if (byMatch.get(am.bm.id) != am) return;
        am.bm.state = MState.RESETTING;
        release(am);
        am.bm.state = MState.FINISHED;
        pl.tournaments.changed();
    }

    /** Frees players and arena (used for normal reset and for cancellation). */
    private void release(Active am) {
        for (UUID u : am.bm.p) {
            frozen.remove(u);
            byPlayer.remove(u, am);
            Player p = Bukkit.getPlayer(u);
            if (p != null) pl.tournaments.afterMatch(p);
        }
        cleanArena(am);
        am.arena.occupiedBy = -1;
        byMatch.remove(am.bm.id);
        pl.spectators.matchEnded(am.bm.id);
    }

    void cleanArena(Active am) {
        for (Block b : am.placed) b.setType(Material.AIR, false);
        am.placed.clear();
        World w = am.arena.spawn1.getWorld();
        for (Entity e : w.getNearbyEntities(am.arena.box)) {
            if (e instanceof Item || e instanceof Projectile || e instanceof EnderCrystal || e instanceof ExperienceOrb || e instanceof AreaEffectCloud) e.remove();
        }
    }

    /** Cancel without a result: the match returns to WAITING and may be started again. */
    void cancelMatch(Active am, String why) {
        if (am.ended) return;
        am.ended = true;
        am.bm.state = MState.WAITING; am.bm.arenaId = -1; am.bm.winner = null;
        release(am);
        pl.tournaments.notifyAdmins("&eMatch #" + am.bm.id + " cancelled (" + why + "). It will be restarted automatically.");
        pl.tournaments.changed();
    }

    void cancelAll() {
        for (Active am : new ArrayList<>(byMatch.values())) {
            am.ended = true;
            if (!am.bm.done()) { am.bm.state = MState.WAITING; am.bm.arenaId = -1; }
            release(am);
        }
    }

    // ---------- disconnects ----------
    void disconnect(Player p) {
        Active am = byPlayer.get(p.getUniqueId());
        if (am == null || am.ended) return;
        int g = pl.settings.num("matches.disconnect-grace-seconds", 30);
        if (g <= 0) { disconnectExpired(am, p.getUniqueId()); return; }
        am.grace.put(p.getUniqueId(), g);
        Player o = Bukkit.getPlayer(am.bm.other(p.getUniqueId()));
        if (o != null) o.sendMessage(Util.c("&e" + p.getName() + " disconnected. They have " + g + "s to reconnect."));
    }

    private void disconnectExpired(Active am, UUID gone) {
        if (am.ended) return;
        UUID other = am.bm.other(gone);
        boolean otherAway = am.grace.containsKey(other) || Bukkit.getPlayer(other) == null;
        String rule = pl.settings.str("matches.forfeit-rule", "LOSS").toUpperCase();
        if (rule.equals("REPLAY") || otherAway) { cancelMatch(am, "disconnect"); return; }
        finish(am, other, gone, "DISCONNECT", true);
    }

    void rejoin(Active am, Player p) {
        am.grace.remove(p.getUniqueId());
        if (am.ended) return;
        p.setGameMode(GameMode.SURVIVAL);
        if (am.bm.state == MState.COUNTDOWN) { p.teleport(p.getUniqueId().equals(am.bm.p[0]) ? am.arena.spawn1 : am.arena.spawn2); frozen.add(p.getUniqueId()); }
        else if (!am.arena.contains(p.getLocation())) p.teleport(p.getUniqueId().equals(am.bm.p[0]) ? am.arena.spawn1 : am.arena.spawn2);
        p.sendMessage(Util.c("&aWelcome back - your match continues."));
        Player o = Bukkit.getPlayer(am.bm.other(p.getUniqueId()));
        if (o != null) o.sendMessage(Util.c("&a" + p.getName() + " reconnected."));
    }
}
