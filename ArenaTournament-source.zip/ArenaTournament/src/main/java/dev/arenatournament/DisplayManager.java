package dev.arenatournament;

import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.TextDisplay;

import java.util.List;

/** Updates the world-space text displays in the lobby and spectator hub (found by scoreboard tag). */
class DisplayManager {
    private final ArenaTournamentPlugin pl;
    DisplayManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    void update() {
        World w = pl.arenas.world();
        if (w == null || w.getPlayers().isEmpty()) return;
        String status = statusText(), hub = hubText();
        for (TextDisplay d : w.getEntitiesByClass(TextDisplay.class)) {
            if (d.getScoreboardTags().contains("at_status")) d.text(Util.c(status));
            else if (d.getScoreboardTags().contains("at_hub")) d.text(Util.c(hub));
        }
    }

    String statusText() {
        Tournament t = pl.tournaments.t;
        StringBuilder sb = new StringBuilder("&6&l" + pl.settings.tname() + "\n");
        if (t == null) return sb.append("&7No tournament scheduled").toString();
        sb.append("&7Status: &f").append(t.status).append("\n&7Players: &f").append(t.players.size()).append("/").append(pl.settings.num("tournament.max-players", 24));
        if (t.status == Status.RUNNING || t.status == Status.PAUSED) sb.append("\n&7Round: &f").append(t.roundName(Math.min(t.currentRound, t.rounds.size() - 1))).append("\n&7Alive: &f").append(t.aliveCount()).append("  &7Live matches: &f").append(pl.matches.running());
        if (t.status == Status.REGISTRATION) sb.append(t.registrationOpen ? "\n&aUse /at join to register!" : "\n&cRegistration closed");
        if (t.champion != null) sb.append("\n&6Champion: &e").append(t.nameOf(t.champion));
        return sb.toString();
    }

    String hubText() {
        Tournament t = pl.tournaments.t;
        StringBuilder sb = new StringBuilder("&b&lLIVE MATCHES\n");
        if (pl.matches.byMatch.isEmpty()) return sb.append("&7None right now").toString();
        for (MatchManager.Active am : pl.matches.byMatch.values())
            sb.append("&eArena ").append(am.arena.label()).append(": &f").append(t.nameOf(am.bm.p[0])).append(" &7vs &f").append(t.nameOf(am.bm.p[1])).append("\n");
        return sb.toString();
    }
}
