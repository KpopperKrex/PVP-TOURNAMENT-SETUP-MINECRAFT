package dev.arenatournament;

import java.util.*;

enum Status { IDLE, REGISTRATION, RUNNING, PAUSED, FINISHED, CANCELLED }

enum MState { WAITING, COUNTDOWN, RUNNING, FINISHED, RESETTING }

class BracketMatch {
    final int id, round, index;
    final UUID[] p = new UUID[2];
    UUID winner;
    MState state = MState.WAITING;
    int arenaId = -1;
    boolean bye;
    String reason = "";

    BracketMatch(int id, int round, int index) { this.id = id; this.round = round; this.index = index; }

    boolean done() { return winner != null; }
    boolean has(UUID u) { return u != null && (u.equals(p[0]) || u.equals(p[1])); }
    UUID other(UUID u) { return u.equals(p[0]) ? p[1] : p[0]; }
    UUID loser() { return (winner == null || p[0] == null || p[1] == null) ? null : other(winner); }
}

class Stats {
    UUID uuid; String name;
    int matches, wins, losses, forfeits, tournaments, titles, best;
    Stats(UUID u, String n) { uuid = u; name = n; }
}

class Tournament {
    long id;
    String name;
    Status status = Status.REGISTRATION;
    boolean registrationOpen = true;
    final LinkedHashMap<UUID, String> players = new LinkedHashMap<>();
    final Map<UUID, Integer> seeds = new HashMap<>();
    final Set<UUID> eliminated = new HashSet<>();
    final Map<UUID, Integer> placement = new HashMap<>();
    final List<List<BracketMatch>> rounds = new ArrayList<>();
    int currentRound, poolSize;
    UUID champion;
    long startedAt, endedAt;

    String nameOf(UUID u) { return u == null ? "TBD" : players.getOrDefault(u, "?"); }
    boolean alive(UUID u) { return players.containsKey(u) && !eliminated.contains(u); }
    int aliveCount() { return players.size() - eliminated.size(); }
    int totalMatches() { return Math.max(0, players.size() - 1); }
    boolean active() { return status == Status.REGISTRATION || status == Status.RUNNING || status == Status.PAUSED; }

    String roundName(int r) {
        return switch (poolSize >> r) {
            case 2 -> "GRAND FINAL"; case 4 -> "SEMIFINALS"; case 8 -> "QUARTERFINALS"; case 16 -> "ROUND OF 16";
            default -> "ROUND " + (r + 1);
        };
    }
    String roundKey(int r) { return roundName(r).replace(' ', '_'); }

    List<BracketMatch> all() { List<BracketMatch> l = new ArrayList<>(); rounds.forEach(l::addAll); return l; }
    BracketMatch byId(int id) { for (BracketMatch m : all()) if (m.id == id) return m; return null; }
    int completedMatches() { int c = 0; for (BracketMatch m : all()) if (m.done() && !m.bye) c++; return c; }

    /** Current (unfinished) match of a player, or null. */
    BracketMatch currentMatch(UUID u) {
        for (List<BracketMatch> r : rounds) for (BracketMatch m : r) if (m.has(u) && !m.done()) return m;
        return null;
    }
}
