package dev.arenatournament;

import org.bukkit.Bukkit;

import java.io.File;
import java.sql.*;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/** SQLite storage. All writes run on one background thread inside transactions; reads at startup are synchronous. */
class Database {
    private final ArenaTournamentPlugin pl;
    private Connection conn;
    private final Object lock = new Object();
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> new Thread(r, "ArenaTournament-DB"));

    Database(ArenaTournamentPlugin pl) { this.pl = pl; }

    void init() throws Exception {
        Class.forName("org.sqlite.JDBC");
        pl.getDataFolder().mkdirs();
        File f = new File(pl.getDataFolder(), pl.getConfig().getString("storage.file", "tournament.db"));
        conn = DriverManager.getConnection("jdbc:sqlite:" + f.getAbsolutePath());
        synchronized (lock) {
            try (Statement s = conn.createStatement()) {
                s.execute("PRAGMA journal_mode=WAL");
                s.execute("CREATE TABLE IF NOT EXISTS tournaments(id INTEGER PRIMARY KEY,name TEXT,status TEXT,current_round INTEGER,pool INTEGER,champion TEXT,champion_name TEXT,started_at INTEGER,ended_at INTEGER,reg_open INTEGER)");
                s.execute("CREATE TABLE IF NOT EXISTS participants(tid INTEGER,uuid TEXT,name TEXT,seed INTEGER,eliminated INTEGER,placement INTEGER,PRIMARY KEY(tid,uuid))");
                s.execute("CREATE TABLE IF NOT EXISTS matches(tid INTEGER,id INTEGER,round INTEGER,idx INTEGER,p1 TEXT,p2 TEXT,winner TEXT,state TEXT,arena INTEGER,bye INTEGER,reason TEXT,PRIMARY KEY(tid,id))");
                s.execute("CREATE TABLE IF NOT EXISTS player_state(uuid TEXT PRIMARY KEY,data TEXT,saved_at INTEGER)");
                s.execute("CREATE TABLE IF NOT EXISTS stats(uuid TEXT PRIMARY KEY,name TEXT,matches INTEGER,wins INTEGER,losses INTEGER,forfeits INTEGER,tournaments INTEGER,titles INTEGER,best INTEGER)");
            }
        }
    }

    void shutdown() {
        exec.shutdown();
        try { exec.awaitTermination(15, TimeUnit.SECONDS); } catch (InterruptedException ignored) {}
        synchronized (lock) { try { if (conn != null) conn.close(); } catch (SQLException ignored) {} }
    }

    private void update(String sql, Object... args) throws SQLException {
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            for (int i = 0; i < args.length; i++) ps.setObject(i + 1, args[i]);
            ps.executeUpdate();
        }
    }
    private void async(String what, SqlTask task) {
        exec.submit(() -> {
            synchronized (lock) {
                try { task.run(); } catch (Exception e) {
                    pl.getLogger().severe("DB error (" + what + "): " + e.getMessage());
                    try { if (!conn.getAutoCommit()) { conn.rollback(); conn.setAutoCommit(true); } } catch (SQLException ignored) {}
                }
            }
        });
    }
    private interface SqlTask { void run() throws Exception; }

    // ---------- tournament ----------
    /** Snapshot on the calling (main) thread, write asynchronously in one transaction. */
    void saveTournament(Tournament t) {
        final long id = t.id;
        final Object[] trow = {id, t.name, t.status.name(), t.currentRound, t.poolSize, t.champion == null ? null : t.champion.toString(),
                t.champion == null ? null : t.nameOf(t.champion), t.startedAt, t.endedAt, t.registrationOpen ? 1 : 0};
        List<Object[]> prow = new ArrayList<>();
        for (Map.Entry<UUID, String> e : t.players.entrySet())
            prow.add(new Object[]{id, e.getKey().toString(), e.getValue(), t.seeds.getOrDefault(e.getKey(), 0), t.eliminated.contains(e.getKey()) ? 1 : 0, t.placement.getOrDefault(e.getKey(), 0)});
        List<Object[]> mrow = new ArrayList<>();
        for (BracketMatch m : t.all())
            mrow.add(new Object[]{id, m.id, m.round, m.index, m.p[0] == null ? null : m.p[0].toString(), m.p[1] == null ? null : m.p[1].toString(),
                    m.winner == null ? null : m.winner.toString(), m.state.name(), m.arenaId, m.bye ? 1 : 0, m.reason});
        async("saveTournament", () -> {
            conn.setAutoCommit(false);
            update("INSERT OR REPLACE INTO tournaments VALUES(?,?,?,?,?,?,?,?,?,?)", trow);
            update("DELETE FROM participants WHERE tid=?", id);
            for (Object[] r : prow) update("INSERT INTO participants VALUES(?,?,?,?,?,?)", r);
            update("DELETE FROM matches WHERE tid=?", id);
            for (Object[] r : mrow) update("INSERT INTO matches VALUES(?,?,?,?,?,?,?,?,?,?,?)", r);
            conn.commit();
            conn.setAutoCommit(true);
        });
    }

    /** Loads the newest unfinished tournament (startup only, synchronous). */
    Tournament loadActive() {
        synchronized (lock) {
            try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM tournaments WHERE status IN ('REGISTRATION','RUNNING','PAUSED') ORDER BY id DESC LIMIT 1")) {
                if (!rs.next()) return null;
                Tournament t = new Tournament();
                t.id = rs.getLong("id"); t.name = rs.getString("name"); t.status = Status.valueOf(rs.getString("status"));
                t.currentRound = rs.getInt("current_round"); t.poolSize = rs.getInt("pool");
                String ch = rs.getString("champion"); t.champion = ch == null ? null : UUID.fromString(ch);
                t.startedAt = rs.getLong("started_at"); t.endedAt = rs.getLong("ended_at"); t.registrationOpen = rs.getInt("reg_open") == 1;
                try (PreparedStatement ps = conn.prepareStatement("SELECT * FROM participants WHERE tid=? ORDER BY seed")) {
                    ps.setLong(1, t.id);
                    try (ResultSet pr = ps.executeQuery()) {
                        while (pr.next()) {
                            UUID u = UUID.fromString(pr.getString("uuid"));
                            t.players.put(u, pr.getString("name"));
                            if (pr.getInt("seed") > 0) t.seeds.put(u, pr.getInt("seed"));
                            if (pr.getInt("eliminated") == 1) t.eliminated.add(u);
                            if (pr.getInt("placement") > 0) t.placement.put(u, pr.getInt("placement"));
                        }
                    }
                }
                int rounds = t.poolSize > 1 ? Integer.numberOfTrailingZeros(t.poolSize) : 0;
                for (int i = 0; i < rounds; i++) t.rounds.add(new ArrayList<>());
                try (PreparedStatement ps = conn.prepareStatement("SELECT * FROM matches WHERE tid=? ORDER BY round, idx")) {
                    ps.setLong(1, t.id);
                    try (ResultSet mr = ps.executeQuery()) {
                        while (mr.next()) {
                            BracketMatch m = new BracketMatch(mr.getInt("id"), mr.getInt("round"), mr.getInt("idx"));
                            String a = mr.getString("p1"), b = mr.getString("p2"), w = mr.getString("winner");
                            m.p[0] = a == null ? null : UUID.fromString(a); m.p[1] = b == null ? null : UUID.fromString(b);
                            m.winner = w == null ? null : UUID.fromString(w);
                            m.state = MState.valueOf(mr.getString("state")); m.arenaId = mr.getInt("arena");
                            m.bye = mr.getInt("bye") == 1; m.reason = mr.getString("reason") == null ? "" : mr.getString("reason");
                            t.rounds.get(m.round).add(m);
                        }
                    }
                }
                return t;
            } catch (Exception e) {
                pl.getLogger().severe("Could not load unfinished tournament: " + e.getMessage());
                return null;
            }
        }
    }

    // ---------- player state ----------
    Map<UUID, String> loadStates() {
        Map<UUID, String> m = new HashMap<>();
        synchronized (lock) {
            try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT uuid,data FROM player_state")) {
                while (rs.next()) m.put(UUID.fromString(rs.getString(1)), rs.getString(2));
            } catch (SQLException e) { pl.getLogger().severe("loadStates: " + e.getMessage()); }
        }
        return m;
    }
    void putState(UUID u, String data) { async("putState", () -> update("INSERT OR REPLACE INTO player_state VALUES(?,?,?)", u.toString(), data, System.currentTimeMillis())); }
    void deleteState(UUID u) { async("deleteState", () -> update("DELETE FROM player_state WHERE uuid=?", u.toString())); }

    // ---------- stats ----------
    Map<UUID, Stats> loadStats() {
        Map<UUID, Stats> m = new HashMap<>();
        synchronized (lock) {
            try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT * FROM stats")) {
                while (rs.next()) {
                    Stats st = new Stats(UUID.fromString(rs.getString("uuid")), rs.getString("name"));
                    st.matches = rs.getInt("matches"); st.wins = rs.getInt("wins"); st.losses = rs.getInt("losses");
                    st.forfeits = rs.getInt("forfeits"); st.tournaments = rs.getInt("tournaments"); st.titles = rs.getInt("titles"); st.best = rs.getInt("best");
                    m.put(st.uuid, st);
                }
            } catch (SQLException e) { pl.getLogger().severe("loadStats: " + e.getMessage()); }
        }
        return m;
    }
    void saveStats(Stats s) {
        final Object[] r = {s.uuid.toString(), s.name, s.matches, s.wins, s.losses, s.forfeits, s.tournaments, s.titles, s.best};
        async("saveStats", () -> update("INSERT OR REPLACE INTO stats VALUES(?,?,?,?,?,?,?,?,?)", r));
    }

    // ---------- history ----------
    void history(int limit, Consumer<List<String>> cb) {
        exec.submit(() -> {
            List<String> out = new ArrayList<>();
            synchronized (lock) {
                try (Statement s = conn.createStatement(); ResultSet rs = s.executeQuery("SELECT id,name,status,champion_name,started_at FROM tournaments ORDER BY id DESC LIMIT " + limit)) {
                    while (rs.next()) out.add("#" + rs.getLong(1) + " " + rs.getString(2) + " [" + rs.getString(3) + "] champion: " + (rs.getString(4) == null ? "-" : rs.getString(4)) + " started: " + new java.util.Date(rs.getLong(5)));
                } catch (SQLException e) { out.add("DB error: " + e.getMessage()); }
            }
            Bukkit.getScheduler().runTask(pl, () -> cb.accept(out));
        });
    }
}
