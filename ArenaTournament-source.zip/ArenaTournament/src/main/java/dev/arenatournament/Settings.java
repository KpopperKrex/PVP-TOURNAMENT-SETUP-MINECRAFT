package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.List;

/** Reads config.yml, with GUI/runtime overrides from overrides.yml taking priority. */
class Settings {
    private final ArenaTournamentPlugin pl;
    private final File file;
    private YamlConfiguration ov;

    Settings(ArenaTournamentPlugin pl) { this.pl = pl; this.file = new File(pl.getDataFolder(), "overrides.yml"); load(); }

    void load() { pl.reloadConfig(); ov = YamlConfiguration.loadConfiguration(file); }

    private Object raw(String p) { return ov.contains(p) ? ov.get(p) : pl.getConfig().get(p); }
    String str(String p, String d) { Object o = raw(p); return o == null ? d : String.valueOf(o); }
    int num(String p, int d) {
        Object o = raw(p);
        if (o instanceof Number n) return n.intValue();
        try { return o == null ? d : Integer.parseInt(String.valueOf(o)); } catch (NumberFormatException e) { return d; }
    }
    boolean bool(String p, boolean d) { Object o = raw(p); return o instanceof Boolean b ? b : d; }
    List<String> list(String p) { return ov.contains(p) ? ov.getStringList(p) : pl.getConfig().getStringList(p); }
    void set(String p, Object v) { ov.set(p, v); try { ov.save(file); } catch (IOException e) { pl.getLogger().warning("Cannot save overrides.yml: " + e.getMessage()); } }

    String prefix() { return str("branding.prefix", "&8[&6TOURNAMENT&8] &7"); }
    String server() { return str("branding.server-name", "YOUR SERVER"); }
    String tname() { return str("branding.tournament-name", "PVP CHAMPIONSHIP"); }

    String msg(String key, String... kv) {
        String s = pl.getConfig().getString("messages." + key, key);
        for (int i = 0; i + 1 < kv.length; i += 2) s = s.replace(kv[i], kv[i + 1]);
        return s;
    }
    /** Broadcast with the tournament prefix. */
    void bcast(String key, String... kv) { Bukkit.getServer().broadcast(Util.c(prefix() + msg(key, kv))); }
    /** Broadcast the message stored under "<key>-raw" without prefix. */
    void bcastRaw(String key, String... kv) { Bukkit.getServer().broadcast(Util.c(msg(key + "-raw", kv))); }
}
