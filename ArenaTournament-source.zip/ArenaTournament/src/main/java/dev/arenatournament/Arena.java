package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.util.BoundingBox;

import java.util.LinkedHashMap;
import java.util.Map;

class Arena {
    final int id;
    final boolean stadium;
    String name, theme = "";
    boolean enabled = true;
    String worldName;
    Location spawn1, spawn2, spectate;
    BoundingBox box;
    int occupiedBy = -1;

    Arena(int id, String name, boolean stadium) { this.id = id; this.name = name; this.stadium = stadium; }

    boolean free() { return enabled && occupiedBy < 0; }
    String label() { return stadium ? "STADIUM" : String.valueOf(id); }

    boolean contains(Location l) {
        return l.getWorld() != null && l.getWorld().getName().equals(worldName) && box.contains(l.getX(), l.getY(), l.getZ());
    }

    /** null = usable, otherwise a human-readable reason. */
    String problem() {
        if (!enabled) return "disabled";
        World w = Bukkit.getWorld(worldName);
        if (w == null) return "world '" + worldName + "' is not loaded";
        if (spawn1 == null || spawn2 == null || spectate == null || box == null) return "missing spawn/spectator/boundary data";
        if (!contains(spawn1) || !contains(spawn2)) return "a spawn is outside the arena boundary";
        if (spawn1.distance(spawn2) < 4) return "spawns are too close together";
        for (Location l : new Location[]{spawn1, spawn2}) {
            Block feet = l.getBlock();
            if (!feet.isPassable() || !feet.getRelative(0, 1, 0).isPassable()) return "a spawn is obstructed";
            if (!feet.getRelative(0, -1, 0).getType().isSolid()) return "no floor below a spawn";
        }
        return null;
    }

    Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("name", name); m.put("theme", theme); m.put("enabled", enabled);
        m.put("spawn1", Util.ser(spawn1)); m.put("spawn2", Util.ser(spawn2)); m.put("spectate", Util.ser(spectate));
        Map<String, Object> mn = new LinkedHashMap<>(), mx = new LinkedHashMap<>();
        mn.put("x", box.getMinX()); mn.put("y", box.getMinY()); mn.put("z", box.getMinZ());
        mx.put("x", box.getMaxX()); mx.put("y", box.getMaxY()); mx.put("z", box.getMaxZ());
        m.put("min", mn); m.put("max", mx);
        return m;
    }

    static Arena from(World w, int id, boolean stadium, ConfigurationSection s) {
        Arena a = new Arena(id, s.getString("name", stadium ? "Grand Stadium" : "Arena " + id), stadium);
        a.theme = s.getString("theme", ""); a.enabled = s.getBoolean("enabled", true); a.worldName = w.getName();
        a.spawn1 = Util.loc(w, s.getConfigurationSection("spawn1"));
        a.spawn2 = Util.loc(w, s.getConfigurationSection("spawn2"));
        a.spectate = Util.loc(w, s.getConfigurationSection("spectate"));
        ConfigurationSection mn = s.getConfigurationSection("min"), mx = s.getConfigurationSection("max");
        if (mn != null && mx != null) a.box = new BoundingBox(mn.getDouble("x"), mn.getDouble("y"), mn.getDouble("z"), mx.getDouble("x"), mx.getDouble("y"), mx.getDouble("z"));
        return a;
    }
}
