package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.*;

import java.util.*;

/** Per-player sidebar. Only lines whose text actually changed are rewritten. */
class SidebarManager {
    private static class Board {
        final Scoreboard sb = Bukkit.getScoreboardManager().getNewScoreboard();
        final Objective obj;
        final String[] last = new String[15];
        String title = "";
        int count;
        Board() {
            obj = sb.registerNewObjective("at", Criteria.DUMMY, Util.c(""));
            obj.setDisplaySlot(DisplaySlot.SIDEBAR);
            for (int i = 0; i < 15; i++) sb.registerNewTeam("l" + i).addEntry(entry(i));
        }
    }
    private static String entry(int i) { return "\u00a7" + Integer.toHexString(i); }

    private final ArenaTournamentPlugin pl;
    private final Map<UUID, Board> boards = new HashMap<>();

    SidebarManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    void updateAll() {
        boolean on = pl.settings.bool("scoreboard.enabled", true);
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (on && pl.tournaments.t != null && pl.tournaments.inTournamentView(p)) update(p); else remove(p);
        }
        boards.keySet().removeIf(u -> Bukkit.getPlayer(u) == null);
    }

    void remove(Player p) {
        if (boards.remove(p.getUniqueId()) != null) p.setScoreboard(Bukkit.getScoreboardManager().getMainScoreboard());
    }

    private void update(Player p) {
        Board b = boards.computeIfAbsent(p.getUniqueId(), k -> new Board());
        if (p.getScoreboard() != b.sb) p.setScoreboard(b.sb);
        String title = fill(pl.settings.str("scoreboard.title", "%server%"), p);
        if (!title.equals(b.title)) { b.title = title; b.obj.displayName(Util.c(title)); }
        List<String> tpl = pl.settings.list("scoreboard.lines." + mode(p));
        int n = Math.min(15, tpl.size());
        boolean countChanged = n != b.count;
        for (int i = 0; i < n; i++) {
            String line = fill(tpl.get(i), p);
            if (!line.equals(b.last[i])) { b.last[i] = line; b.sb.getTeam("l" + i).prefix(Util.c(line)); }
            if (countChanged || b.obj.getScore(entry(i)).getScore() != n - i) b.obj.getScore(entry(i)).setScore(n - i);
        }
        for (int i = n; i < 15; i++) if (b.last[i] != null) { b.last[i] = null; b.sb.resetScores(entry(i)); }
        b.count = n;
    }

    private String mode(Player p) {
        Tournament t = pl.tournaments.t;
        if (t.status == Status.REGISTRATION) return "waiting";
        if (pl.matches.of(p.getUniqueId()) != null) return "in-match";
        return "running";
    }

    private String fill(String s, Player p) {
        Tournament t = pl.tournaments.t;
        UUID u = p.getUniqueId();
        Stats st = pl.tournaments.stats.get(u);
        String round = t.status == Status.REGISTRATION ? "-" : t.rounds.isEmpty() ? "-" : t.status == Status.FINISHED ? "FINISHED" : t.roundName(Math.min(t.currentRound, t.rounds.size() - 1));
        MatchManager.Active am = pl.matches.of(u);
        String opp = "-", arena = "-", status = status(p, t, am);
        if (am != null) { opp = t.nameOf(am.bm.other(u)); arena = am.arena.label(); }
        else { BracketMatch m = t.currentMatch(u); if (m != null && m.other(u) != null) opp = t.nameOf(m.other(u)); }
        int total = t.totalMatches(), done = t.completedMatches();
        return s.replace("%server%", pl.settings.server()).replace("%tournament%", pl.settings.tname()).replace("%website%", pl.settings.str("branding.website", ""))
                .replace("%status%", status).replace("%round%", round)
                .replace("%registered%", String.valueOf(t.players.size())).replace("%max%", String.valueOf(pl.settings.num("tournament.max-players", 24)))
                .replace("%players%", String.valueOf(t.status == Status.REGISTRATION ? t.players.size() : t.aliveCount()))
                .replace("%active%", String.valueOf(pl.matches.running())).replace("%completed%", String.valueOf(done)).replace("%total%", String.valueOf(total))
                .replace("%progress%", total == 0 ? "0%" : (done * 100 / total) + "%")
                .replace("%you%", p.getName()).replace("%opponent%", opp).replace("%arena%", arena)
                .replace("%wins%", String.valueOf(st == null ? 0 : st.wins)).replace("%losses%", String.valueOf(st == null ? 0 : st.losses));
    }

    private String status(Player p, Tournament t, MatchManager.Active am) {
        UUID u = p.getUniqueId();
        if (t.status == Status.REGISTRATION) return t.registrationOpen ? "REGISTRATION OPEN" : "REGISTRATION CLOSED";
        if (t.status == Status.CANCELLED) return "CANCELLED";
        if (t.status == Status.FINISHED) return u.equals(t.champion) ? "CHAMPION" : "FINISHED";
        if (am != null) return am.bm.state == MState.COUNTDOWN ? "STARTING" : "LIVE";
        if (pl.spectators.watchesLive(u)) return "SPECTATING";
        if (!t.players.containsKey(u)) return "SPECTATOR";
        if (t.eliminated.contains(u)) return "ELIMINATED";
        if (t.currentRound == 0 && !t.rounds.isEmpty()) for (BracketMatch m : t.rounds.get(0)) if (m.bye && m.has(u)) return "BYE";
        return "WAITING";
    }
}
