package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.PluginCommand;
import org.bukkit.plugin.java.JavaPlugin;

public class ArenaTournamentPlugin extends JavaPlugin {
    Settings settings;
    Database db;
    PlayerStateManager states;
    KitManager kits;
    ArenaManager arenas;
    TournamentManager tournaments;
    MatchManager matches;
    SpectatorManager spectators;
    SidebarManager sidebar;
    DisplayManager displays;
    GuiManager guis;
    WorldBuilder builder;
    private int tickCount;

    @Override public void onEnable() {
        saveDefaultConfig();
        settings = new Settings(this);
        db = new Database(this);
        try { db.init(); } catch (Exception e) {
            getLogger().severe("SQLite initialisation failed: " + e.getMessage());
            getServer().getPluginManager().disablePlugin(this);
            return;
        }
        states = new PlayerStateManager(this);
        kits = new KitManager(this);
        arenas = new ArenaManager(this);
        tournaments = new TournamentManager(this);
        matches = new MatchManager(this);
        spectators = new SpectatorManager(this);
        sidebar = new SidebarManager(this);
        displays = new DisplayManager(this);
        guis = new GuiManager(this);
        builder = new WorldBuilder(this);

        Bukkit.getPluginManager().registerEvents(new MatchListener(this), this);
        Bukkit.getPluginManager().registerEvents(new ProtectionListener(this), this);
        Bukkit.getPluginManager().registerEvents(guis, this);
        AtCommand cmd = new AtCommand(this);
        PluginCommand pc = getCommand("at");
        pc.setExecutor(cmd); pc.setTabCompleter(cmd);

        // After all worlds are loaded: world, arenas, crash recovery.
        Bukkit.getScheduler().runTask(this, () -> {
            if (!arenas.load()) {
                if (settings.bool("world.auto-build", true) && !arenas.file().exists()) {
                    getLogger().info("No arenas.yml found - building the tournament world (auto-build).");
                    builder.build(Bukkit.getConsoleSender());
                } else getLogger().warning("Arenas are not loaded. Run /at setup build or fix arenas.yml, then /at reload.");
            }
            tournaments.recover();
            for (org.bukkit.entity.Player p : Bukkit.getOnlinePlayers()) tournaments.onJoin(p);
        });

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            tickCount++;
            matches.tick();
            tournaments.tick();
            sidebar.updateAll();
            if (tickCount % 2 == 0) guis.refreshAll();
            if (tickCount % 5 == 0) displays.update();
            if (tickCount % 30 == 0) { World w = arenas.world(); if (w != null) { w.setTime(6000); w.setStorm(false); } }
        }, 40L, 20L);
        getLogger().info("ArenaTournament enabled.");
    }

    @Override public void onDisable() {
        if (db != null) {
            if (tournaments != null && tournaments.t != null) db.saveTournament(tournaments.t);
            db.shutdown();
        }
    }

    /** Refresh everything that displays tournament data. */
    void refreshViews() {
        if (sidebar != null) { sidebar.updateAll(); guis.refreshAll(); displays.update(); }
    }
}
