package dev.arenatournament;

import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldguard.WorldGuard;
import com.sk89q.worldguard.protection.flags.Flags;
import com.sk89q.worldguard.protection.flags.StateFlag;
import com.sk89q.worldguard.protection.managers.RegionManager;
import com.sk89q.worldguard.protection.regions.ProtectedCuboidRegion;
import org.bukkit.World;
import org.bukkit.util.BoundingBox;

import java.util.ArrayList;
import java.util.List;

/**
 * Optional WorldGuard integration. This class is only ever loaded when WorldGuard is installed
 * (AtCommand checks the plugin manager first), so WorldGuard is NOT a hard dependency.
 * It only CREATES regions named at_* that do not exist yet and never touches any other region.
 */
final class WorldGuardHook {
    private WorldGuardHook() {}

    static List<String> createRegions(ArenaTournamentPlugin pl) {
        List<String> log = new ArrayList<>();
        World w = pl.arenas.world();
        if (w == null) { log.add("World not loaded."); return log; }
        RegionManager rm = WorldGuard.getInstance().getPlatform().getRegionContainer().get(BukkitAdapter.adapt(w));
        if (rm == null) { log.add("WorldGuard has no region manager for this world."); return log; }
        // Whole tournament world: no building, no mobs, no pvp (arenas override with higher priority).
        add(rm, "at_world", new BoundingBox(-400, -64, -200, 400, 320, 600), 1, false, log);
        for (Arena a : pl.arenas.arenas.values()) add(rm, "at_arena_" + a.id, a.box, 10, true, log);
        if (pl.arenas.stadium != null) add(rm, "at_stadium", pl.arenas.stadium.box, 10, true, log);
        try { rm.save(); } catch (Exception e) { log.add("Could not save regions: " + e.getMessage()); }
        return log;
    }

    private static void add(RegionManager rm, String id, BoundingBox b, int prio, boolean pvp, List<String> log) {
        if (rm.hasRegion(id)) { log.add("Region " + id + " already exists - left untouched."); return; }
        ProtectedCuboidRegion r = new ProtectedCuboidRegion(id,
                BlockVector3.at(b.getMinX(), b.getMinY(), b.getMinZ()), BlockVector3.at(b.getMaxX() - 1, b.getMaxY() - 1, b.getMaxZ() - 1));
        r.setPriority(prio);
        r.setFlag(Flags.BUILD, StateFlag.State.DENY);
        r.setFlag(Flags.MOB_SPAWNING, StateFlag.State.DENY);
        r.setFlag(Flags.PVP, pvp ? StateFlag.State.ALLOW : StateFlag.State.DENY);
        rm.addRegion(r);
        log.add("Created region " + id);
    }
}
