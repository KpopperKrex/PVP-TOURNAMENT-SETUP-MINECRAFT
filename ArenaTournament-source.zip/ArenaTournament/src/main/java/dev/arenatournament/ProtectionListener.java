package dev.arenatournament;

import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.*;
import org.bukkit.event.entity.*;
import org.bukkit.event.hanging.HangingBreakEvent;
import org.bukkit.event.player.*;
import org.bukkit.event.weather.WeatherChangeEvent;

/**
 * Built-in protection of the tournament world (works with or without WorldGuard).
 * Only tracked blocks placed by a fighter in an active match (CRYSTAL/UHC mode) can be placed or broken.
 */
class ProtectionListener implements Listener {
    private final ArenaTournamentPlugin pl;
    ProtectionListener(ArenaTournamentPlugin pl) { this.pl = pl; }

    private boolean inWorld(Entity e) { return pl.arenas.world() != null && e.getWorld().equals(pl.arenas.world()); }
    private boolean inWorld(Block b) { return pl.arenas.world() != null && b.getWorld().equals(pl.arenas.world()); }
    private boolean bypass(Player p) { return p.hasPermission("arenatournament.bypass") && p.getGameMode() == org.bukkit.GameMode.CREATIVE; }

    @EventHandler(ignoreCancelled = true)
    public void onPlace(BlockPlaceEvent e) {
        Player p = e.getPlayer();
        if (!inWorld(e.getBlock()) || bypass(p)) return;
        MatchManager.Active am = pl.matches.of(p.getUniqueId());
        if (am != null && am.bm.state == MState.RUNNING && am.arena.contains(e.getBlock().getLocation())) {
            String mode = pl.kits.mode();
            for (String s : pl.settings.list("combat.modes." + mode + ".placeable"))
                if (s.equalsIgnoreCase(e.getBlockPlaced().getType().name())) { am.placed.add(e.getBlockPlaced()); return; }
        }
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBreak(BlockBreakEvent e) {
        Player p = e.getPlayer();
        if (!inWorld(e.getBlock()) || bypass(p)) return;
        MatchManager.Active am = pl.matches.of(p.getUniqueId());
        if (am != null && am.placed.remove(e.getBlock())) { e.setDropItems(false); return; }
        e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true) public void onBucket(PlayerBucketEmptyEvent e) { if (inWorld(e.getBlock()) && !bypass(e.getPlayer())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onBucketFill(PlayerBucketFillEvent e) { if (inWorld(e.getBlock()) && !bypass(e.getPlayer())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onDrop(PlayerDropItemEvent e) { if (inWorld(e.getPlayer()) && !bypass(e.getPlayer())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onPickup(EntityPickupItemEvent e) { if (e.getEntity() instanceof Player p && inWorld(p) && !bypass(p)) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onSwap(PlayerSwapHandItemsEvent e) { if (pl.matches.frozen.contains(e.getPlayer().getUniqueId())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onEntityInteract(PlayerInteractEntityEvent e) {
        if (inWorld(e.getPlayer()) && !bypass(e.getPlayer())) e.setCancelled(true);
    }
    @EventHandler(ignoreCancelled = true) public void onArmorStand(PlayerArmorStandManipulateEvent e) { if (inWorld(e.getPlayer()) && !bypass(e.getPlayer())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onHanging(HangingBreakEvent e) { if (inWorld(e.getEntity())) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onExplode(EntityExplodeEvent e) { if (inWorld(e.getEntity())) e.blockList().clear(); }
    @EventHandler(ignoreCancelled = true)
    public void onBlockExplode(BlockExplodeEvent e) { if (inWorld(e.getBlock())) e.blockList().clear(); }
    @EventHandler(ignoreCancelled = true) public void onBurn(BlockBurnEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onIgnite(BlockIgniteEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onSpread(BlockSpreadEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onFade(BlockFadeEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onForm(BlockFormEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onFlow(BlockFromToEvent e) { if (inWorld(e.getBlock())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onSpawn(CreatureSpawnEvent e) { if (inWorld(e.getEntity())) e.setCancelled(true); }
    @EventHandler(ignoreCancelled = true) public void onWeather(WeatherChangeEvent e) { if (pl.arenas.world() != null && e.getWorld().equals(pl.arenas.world()) && e.toWeatherState()) e.setCancelled(true); }

    @EventHandler(ignoreCancelled = true)
    public void onDamageEntity(EntityDamageByEntityEvent e) {
        // Spectators/lobby players can never hurt anyone; non-player entities in the world are untouchable (displays etc.)
        if (!(e.getEntity() instanceof Player) && !(e.getEntity() instanceof org.bukkit.entity.EnderCrystal) && inWorld(e.getEntity()) && !(e.getDamager() instanceof Player p && bypass(p))) e.setCancelled(true);
    }
}
