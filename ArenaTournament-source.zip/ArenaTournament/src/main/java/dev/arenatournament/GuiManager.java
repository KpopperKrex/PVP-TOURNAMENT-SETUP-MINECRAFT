package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.ItemStack;

import java.util.*;

/** All inventory interfaces. Every GUI is read-only: clicks are always cancelled. */
class GuiManager implements Listener {
    private final ArenaTournamentPlugin pl;
    private final Map<UUID, String> confirm = new HashMap<>();
    private final Map<UUID, Long> confirmAt = new HashMap<>();

    GuiManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    // ---------- plumbing ----------
    @EventHandler public void onClick(InventoryClickEvent e) {
        if (e.getView().getTopInventory().getHolder() instanceof Gui g) {
            e.setCancelled(true);
            if (e.getClickedInventory() != null && e.getClickedInventory().equals(g.inv)) {
                var a = g.actions.get(e.getSlot());
                if (a != null) a.accept(e);
            }
        }
    }
    @EventHandler public void onDrag(InventoryDragEvent e) { if (e.getView().getTopInventory().getHolder() instanceof Gui) e.setCancelled(true); }

    void refreshAll() {
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (p.getOpenInventory().getTopInventory().getHolder() instanceof Gui g && g.refresher != null) g.refresher.run();
        }
    }

    private void pane(Gui g) {
        ItemStack f = Util.item(Material.GRAY_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < g.size; i++) g.set(i, f, null);
    }

    private void reply(Player p, String err) {
        if (err != null) p.sendMessage(Util.c("&c" + err)); else p.sendMessage(Util.c("&aDone."));
    }

    private boolean confirmed(Player p, String key) {
        long now = System.currentTimeMillis();
        if (key.equals(confirm.get(p.getUniqueId())) && now - confirmAt.getOrDefault(p.getUniqueId(), 0L) < 8000) { confirm.remove(p.getUniqueId()); return true; }
        confirm.put(p.getUniqueId(), key); confirmAt.put(p.getUniqueId(), now);
        p.sendMessage(Util.c("&eClick again within 8 seconds to confirm."));
        return false;
    }

    private Gui build(String title, int rows, java.util.function.Consumer<Gui> content) {
        Gui g = new Gui(title, rows);
        g.refresher = () -> { g.clear(); pane(g); content.accept(g); };
        g.refresher.run();
        return g;
    }

    // ---------- match presentation ----------
    private String tag(Tournament t, BracketMatch m, UUID u) {
        if (u == null) return "&8TBD";
        String n = t.nameOf(u);
        if (m.bye) return "&b" + n + " &7[BYE]";
        if (m.done()) return u.equals(m.winner) ? "&a" + n + " &7[WIN]" : "&c" + n + " &7[ELIMINATED]";
        if (m.state == MState.RUNNING || m.state == MState.COUNTDOWN) return "&f" + n + " &7[LIVE]";
        return "&f" + n + " &7[WAITING]";
    }

    private ItemStack matchItem(Tournament t, BracketMatch m) {
        Material mat; String st;
        if (m.bye) { mat = Material.LIGHT_BLUE_CONCRETE; st = "&bBYE"; }
        else if (m.done()) { mat = Material.LIME_CONCRETE; st = "&aCOMPLETED"; }
        else if (m.state == MState.RUNNING || m.state == MState.COUNTDOWN) { mat = Material.RED_CONCRETE; st = "&cLIVE"; }
        else if (m.p[0] == null || m.p[1] == null) { mat = Material.GRAY_CONCRETE; st = "&7WAITING FOR PREVIOUS ROUND"; }
        else { mat = Material.YELLOW_CONCRETE; st = "&eWAITING"; }
        List<String> lore = new ArrayList<>();
        lore.add("&7" + t.roundName(m.round));
        lore.add(tag(t, m, m.p[0])); lore.add("&7vs"); lore.add(m.bye ? "&8(no opponent)" : tag(t, m, m.p[1]));
        lore.add("&7Status: " + st);
        if (m.done() && !m.bye) { lore.add("&aAdvanced: &f" + t.nameOf(m.winner)); lore.add("&cEliminated: &f" + t.nameOf(m.loser())); lore.add("&7Reason: " + m.reason); }
        if (m.arenaId >= 0 && !m.done() && m.state != MState.WAITING) { Arena a = pl.arenas.byId(m.arenaId); if (a != null) lore.add("&7Arena: &f" + a.label()); }
        if (m.state == MState.RUNNING || m.state == MState.COUNTDOWN) lore.add("&eClick to spectate");
        return Util.item(mat, "&6Match #" + m.id, lore);
    }

    private void clickSpectate(Player p, BracketMatch m) {
        MatchManager.Active am = pl.matches.ofMatch(m.id);
        if (am == null) return;
        String err = pl.spectators.spectate(p, am);
        if (err != null) p.sendMessage(Util.c("&c" + err));
    }

    // ---------- 1. main menu ----------
    void mainMenu(Player p) {
        build("&8" + Util.plain(pl.settings.tname()), 3, g -> {
            g.set(10, Util.item(Material.OAK_SIGN, "&6Bracket", "&7View the tournament bracket"), e -> bracket(p, -1));
            g.set(11, Util.item(Material.CLOCK, "&6Live Matches", "&7Every match and its result"), e -> liveMatches(p, 0));
            g.set(12, Util.item(Material.ENDER_EYE, "&6Spectate", "&7Watch active matches"), e -> spectateMenu(p));
            g.set(13, Util.item(Material.WRITABLE_BOOK, "&6Registration", "&7See who is registered / join"), e -> registration(p));
            g.set(14, Util.item(Material.DIAMOND_SWORD, "&6My Statistics", "&7Your tournament record"), e -> stats(p, p.getUniqueId()));
            if (p.hasPermission("arenatournament.admin")) g.set(16, Util.item(Material.COMMAND_BLOCK, "&cAdmin Panel", "&7Control the tournament"), e -> admin(p));
        }).open(p);
    }

    // ---------- 2. registration ----------
    void registration(Player p) {
        build("&8Registration", 5, g -> {
            Tournament t = pl.tournaments.t;
            int i = 0;
            if (t != null) for (Map.Entry<UUID, String> e : t.players.entrySet()) { if (i >= 27) break; g.set(i++, Util.item(Material.PLAYER_HEAD, "&f" + e.getValue(), "&7Registered"), null); }
            boolean open = t != null && t.status == Status.REGISTRATION;
            g.set(36, Util.item(Material.LIME_CONCRETE, "&aJoin", open ? "&7Click to register" : "&cRegistration is not open"), e -> { reply(p, pl.tournaments.register(p.getUniqueId(), p.getName(), false)); });
            g.set(37, Util.item(Material.RED_CONCRETE, "&cWithdraw", "&7Leave the registration list"), e -> reply(p, pl.tournaments.unregister(p.getUniqueId())));
            g.set(40, Util.item(Material.PAPER, "&eRegistered: &f" + (t == null ? 0 : t.players.size()) + "/" + pl.settings.num("tournament.max-players", 24),
                    t == null ? "&7No tournament" : "&7Status: &f" + t.status + (t.status == Status.REGISTRATION ? (t.registrationOpen ? " (open)" : " (closed)") : "")), null);
            g.set(44, Util.item(Material.ARROW, "&7Back"), e -> mainMenu(p));
        }).open(p);
    }

    // ---------- 3. live matches ----------
    void liveMatches(Player p, int page) {
        build("&8Live Matches", 6, g -> {
            Tournament t = pl.tournaments.t;
            List<BracketMatch> all = new ArrayList<>();
            if (t != null) { for (BracketMatch m : t.all()) if (!m.bye) all.add(m); for (BracketMatch m : t.all()) if (m.bye) all.add(m); }
            int pages = Math.max(1, (all.size() + 44) / 45), pg = Math.min(page, pages - 1);
            for (int i = 0; i < 45 && pg * 45 + i < all.size(); i++) {
                BracketMatch m = all.get(pg * 45 + i);
                g.set(i, matchItem(t, m), e -> clickSpectate(p, m));
            }
            if (pg > 0) g.set(45, Util.item(Material.ARROW, "&7Previous page"), e -> liveMatches(p, pg - 1));
            g.set(49, Util.item(Material.PAPER, "&ePage " + (pg + 1) + "/" + pages), null);
            if (pg < pages - 1) g.set(53, Util.item(Material.ARROW, "&7Next page"), e -> liveMatches(p, pg + 1));
            g.set(48, Util.item(Material.BARRIER, "&7Back"), e -> mainMenu(p));
        }).open(p);
    }

    // ---------- 4. spectator selector ----------
    void spectateMenu(Player p) {
        if (!pl.settings.bool("spectators.gui-enabled", true)) { p.sendMessage(Util.c("&cThe spectator menu is disabled.")); return; }
        build("&8Spectate a Match", 4, g -> {
            Tournament t = pl.tournaments.t;
            int i = 0;
            for (MatchManager.Active am : pl.matches.byMatch.values()) {
                if (i >= 27) break;
                if (am.ended || (am.bm.state != MState.RUNNING && am.bm.state != MState.COUNTDOWN)) continue;
                g.set(i++, Util.item(am.bm.state == MState.RUNNING ? Material.RED_CONCRETE : Material.YELLOW_CONCRETE, "&6Arena " + am.arena.label(),
                        "&f" + t.nameOf(am.bm.p[0]) + " &7vs &f" + t.nameOf(am.bm.p[1]), "&7Status: " + (am.bm.state == MState.RUNNING ? "&cLIVE" : "&eSTARTING"),
                        "&7Round: &f" + t.roundName(am.bm.round), "&eClick to watch"), e -> {
                    String err = pl.spectators.spectate(p, am);
                    if (err != null) p.sendMessage(Util.c("&c" + err));
                });
            }
            if (i == 0) g.set(13, Util.item(Material.GRAY_DYE, "&7No active matches"), null);
            g.set(31, Util.item(Material.BARRIER, "&cLeave spectating", "&7Return to your normal state"), e -> { p.closeInventory(); pl.spectators.leave(p); });
        }).open(p);
    }

    // ---------- 5. bracket ----------
    void bracket(Player p, int round) {
        Tournament t0 = pl.tournaments.t;
        if (t0 == null || t0.rounds.isEmpty()) { p.sendMessage(Util.c("&cThe bracket has not been generated yet.")); return; }
        final int[] r = {round < 0 ? Math.min(t0.currentRound, t0.rounds.size() - 1) : round};
        build("&8Bracket", 6, g -> {
            Tournament t = pl.tournaments.t;
            if (t == null || t.rounds.isEmpty()) return;
            List<BracketMatch> ms = t.rounds.get(Math.min(r[0], t.rounds.size() - 1));
            for (int i = 0; i < ms.size() && i < 32; i++) { BracketMatch m = ms.get(i); g.set(i + i / 8, matchItem(t, m), e -> clickSpectate(p, m)); }
            for (int i = 0; i < t.rounds.size() && i < 8; i++) {
                final int ri = i;
                g.set(45 + i, Util.item(ri == r[0] ? Material.ENCHANTED_BOOK : Material.BOOK, (ri == r[0] ? "&6&l" : "&e") + t.roundName(ri)), e -> { r[0] = ri; g.refresher.run(); });
            }
            g.set(53, Util.item(Material.NETHER_STAR, "&6&lCHAMPION", t.champion == null ? "&7Not decided yet" : "&e" + t.nameOf(t.champion)), null);
        }).open(p);
    }

    // ---------- 6. stats ----------
    void stats(Player viewer, UUID target) {
        build("&8Player Statistics", 3, g -> {
            Stats s = pl.tournaments.stats.get(target);
            OfflineName n = new OfflineName(target);
            if (s == null) s = new Stats(target, n.name());
            Tournament t = pl.tournaments.t;
            g.set(4, Util.item(Material.PLAYER_HEAD, "&6" + s.name), null);
            g.set(10, Util.item(Material.IRON_SWORD, "&eMatches", "&f" + s.matches), null);
            g.set(11, Util.item(Material.LIME_DYE, "&aWins", "&f" + s.wins), null);
            g.set(12, Util.item(Material.RED_DYE, "&cLosses", "&f" + s.losses), null);
            g.set(13, Util.item(Material.WHITE_BANNER, "&7Forfeits", "&f" + s.forfeits), null);
            g.set(14, Util.item(Material.PAPER, "&bTournaments played", "&f" + s.tournaments), null);
            g.set(15, Util.item(Material.GOLDEN_HELMET, "&6Titles", "&f" + s.titles), null);
            g.set(16, Util.item(Material.NETHER_STAR, "&eBest placement", s.best == 0 ? "&7-" : "&f#" + s.best), null);
            if (t != null && t.players.containsKey(target)) g.set(22, Util.item(Material.COMPASS, "&eCurrent tournament", "&7Seed: &f" + t.seeds.getOrDefault(target, 0),
                    "&7Eliminated: &f" + t.eliminated.contains(target), "&7Placement: &f" + t.placement.getOrDefault(target, 0)), null);
        }).open(viewer);
    }
    private record OfflineName(UUID u) { String name() { String n = Bukkit.getOfflinePlayer(u).getName(); return n == null ? u.toString().substring(0, 8) : n; } }

    // ---------- 7. admin panel ----------
    void admin(Player p) {
        if (!p.hasPermission("arenatournament.admin")) return;
        build("&8Admin Panel", 4, g -> {
            TournamentManager tm = pl.tournaments;
            g.set(10, Util.item(Material.EMERALD_BLOCK, "&aNew tournament / open registration"), e -> reply(p, tm.active() ? tm.openRegistration() : tm.open()));
            g.set(11, Util.item(Material.REDSTONE_BLOCK, "&cClose registration"), e -> reply(p, tm.closeRegistration()));
            g.set(12, Util.item(Material.DIAMOND_BLOCK, "&bStart tournament"), e -> reply(p, tm.start()));
            g.set(13, Util.item(Material.YELLOW_CONCRETE, "&ePause"), e -> reply(p, tm.pause()));
            g.set(14, Util.item(Material.LIME_CONCRETE, "&aResume"), e -> reply(p, tm.resume()));
            g.set(15, Util.item(Material.TNT, "&cCancel tournament", "&7Click twice to confirm"), e -> { if (confirmed(p, "cancel")) reply(p, tm.cancel()); });
            g.set(16, Util.item(Material.BARRIER, "&4Reset tournament data", "&7Click twice to confirm"), e -> { if (confirmed(p, "reset")) reply(p, tm.reset()); });
            g.set(19, Util.item(Material.COMPARATOR, "&6Validate arenas"), e -> { for (String s : pl.arenas.validate()) p.sendMessage(Util.c(s)); });
            g.set(20, Util.item(Material.CHEST, "&6Settings"), e -> settings(p));
            g.set(21, Util.item(Material.CLOCK, "&6Live matches"), e -> liveMatches(p, 0));
            g.set(22, Util.item(Material.OAK_SIGN, "&6Bracket"), e -> bracket(p, -1));
            g.set(23, Util.item(Material.WRITABLE_BOOK, "&6Registered players"), e -> registration(p));
            g.set(24, Util.item(Material.ANVIL, "&6Reload config"), e -> { pl.settings.load(); pl.arenas.load(); p.sendMessage(Util.c("&aReloaded.")); });
            g.set(31, Util.item(Material.PAPER, "&eStatus", "&7" + (tm.t == null ? "No tournament" : tm.t.status + " - " + tm.t.players.size() + " players")), null);
        }).open(p);
    }

    // ---------- 8. settings ----------
    private void cycle(String path, String def, String... vals) {
        String cur = pl.settings.str(path, def).toUpperCase();
        int i = Arrays.asList(vals).indexOf(cur);
        pl.settings.set(path, vals[(i + 1) % vals.length]);
    }
    private void adjust(String path, int def, int step, int min, int max, boolean up) {
        pl.settings.set(path, Math.max(min, Math.min(max, pl.settings.num(path, def) + (up ? step : -step))));
    }

    void settings(Player p) {
        if (!p.hasPermission("arenatournament.admin")) return;
        build("&8Tournament Settings", 3, g -> {
            Settings s = pl.settings;
            g.set(10, Util.item(Material.NAME_TAG, "&6Bye / seeding method", "&f" + s.str("tournament.seeding", "RANDOM"), "&7Click to cycle"), e -> cycle("tournament.seeding", "RANDOM", "RANDOM", "ADMIN", "LEADERBOARD"));
            g.set(11, Util.item(Material.DIAMOND_SWORD, "&6Combat mode", "&f" + s.str("combat.mode", "STANDARD"), "&7Click to cycle"), e -> cycle("combat.mode", "STANDARD", "STANDARD", "CRYSTAL", "UHC"));
            g.set(12, Util.item(Material.CLOCK, "&6Countdown", "&f" + s.num("matches.countdown-seconds", 10) + "s", "&7Left +1 / Right -1"), e -> adjust("matches.countdown-seconds", 10, 1, 3, 30, e.isLeftClick()));
            g.set(13, Util.item(Material.HOPPER, "&6Match timeout", "&f" + s.num("matches.timeout-seconds", 300) + "s", "&7Left +30 / Right -30"), e -> adjust("matches.timeout-seconds", 300, 30, 0, 1800, e.isLeftClick()));
            g.set(14, Util.item(Material.OAK_SIGN, "&6Scoreboard", s.bool("scoreboard.enabled", true) ? "&aON" : "&cOFF"), e -> s.set("scoreboard.enabled", !s.bool("scoreboard.enabled", true)));
            g.set(15, Util.item(Material.ENDER_EYE, "&6Spectators", s.bool("spectators.enabled", true) ? "&aON" : "&cOFF"), e -> s.set("spectators.enabled", !s.bool("spectators.enabled", true)));
            g.set(16, Util.item(Material.TOTEM_OF_UNDYING, "&6Restore eliminated players at once", s.bool("players.restore-eliminated-immediately", false) ? "&aON" : "&cOFF"), e -> s.set("players.restore-eliminated-immediately", !s.bool("players.restore-eliminated-immediately", false)));
            g.set(22, Util.item(Material.ARROW, "&7Back"), e -> admin(p));
        }).open(p);
    }
}
