package dev.arenatournament;

import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;

import java.util.*;

/**
 * Saves a player's real state ONCE (never overwritten while a save exists) and restores it later.
 * Saves are persisted to SQLite so they survive crashes.
 */
class PlayerStateManager {
    private final ArenaTournamentPlugin pl;
    private final Map<UUID, String> saved = new HashMap<>();

    PlayerStateManager(ArenaTournamentPlugin pl) { this.pl = pl; saved.putAll(pl.db.loadStates()); }

    boolean hasSaved(UUID u) { return saved.containsKey(u); }
    Set<UUID> savedIds() { return new HashSet<>(saved.keySet()); }

    /** Saves the state unless one is already stored. Returns true when a new save was made. */
    boolean ensureSaved(Player p) {
        if (saved.containsKey(p.getUniqueId())) return false;
        YamlConfiguration y = new YamlConfiguration();
        List<ItemStack> items = new ArrayList<>();
        for (ItemStack i : p.getInventory().getContents()) items.add(i == null ? new ItemStack(Material.AIR) : i.clone());
        y.set("items", Base64.getEncoder().encodeToString(ItemStack.serializeItemsAsBytes(items)));
        y.set("health", p.getHealth());
        y.set("food", p.getFoodLevel());
        y.set("sat", (double) p.getSaturation());
        y.set("level", p.getLevel());
        y.set("exp", (double) p.getExp());
        y.set("mode", p.getGameMode().name());
        y.set("flight", p.getAllowFlight());
        y.set("flying", p.isFlying());
        y.set("loc", p.getLocation());
        y.set("effects", new ArrayList<>(p.getActivePotionEffects()));
        String data = y.saveToString();
        saved.put(p.getUniqueId(), data);
        pl.db.putState(p.getUniqueId(), data);
        return true;
    }

    /** Restores and forgets the saved state. Returns false when nothing was saved. */
    boolean restore(Player p) {
        String data = saved.remove(p.getUniqueId());
        if (data == null) return false;
        pl.db.deleteState(p.getUniqueId());
        try {
            YamlConfiguration y = new YamlConfiguration();
            y.loadFromString(data);
            p.closeInventory();
            p.getInventory().clear();
            for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
            ItemStack[] items = ItemStack.deserializeItemsFromBytes(Base64.getDecoder().decode(y.getString("items", "")));
            ItemStack[] target = new ItemStack[p.getInventory().getSize()];
            System.arraycopy(items, 0, target, 0, Math.min(items.length, target.length));
            p.getInventory().setContents(target);
            for (Object o : y.getList("effects", List.of())) if (o instanceof PotionEffect e) p.addPotionEffect(e);
            double max = p.getAttribute(Attribute.MAX_HEALTH).getValue();
            p.setHealth(Math.max(1.0, Math.min(max, y.getDouble("health", 20))));
            p.setFoodLevel(y.getInt("food", 20));
            p.setSaturation((float) y.getDouble("sat", 5));
            p.setLevel(y.getInt("level", 0));
            p.setExp((float) y.getDouble("exp", 0));
            p.setFireTicks(0);
            p.setFallDistance(0);
            p.setGameMode(GameMode.valueOf(y.getString("mode", "SURVIVAL")));
            p.setAllowFlight(y.getBoolean("flight", false));
            if (p.getAllowFlight()) p.setFlying(y.getBoolean("flying", false));
            Location loc = y.getLocation("loc");
            if (loc == null || loc.getWorld() == null) loc = pl.getServer().getWorlds().get(0).getSpawnLocation();
            p.teleport(loc);
        } catch (Exception e) {
            pl.getLogger().severe("Failed restoring state of " + p.getName() + ": " + e.getMessage());
            p.sendMessage(Util.c("&cYour saved state could not be fully restored. Contact an administrator."));
        }
        return true;
    }
}
