package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.util.*;

class ArenaManager {
    private final ArenaTournamentPlugin pl;
    final Map<Integer, Arena> arenas = new TreeMap<>();
    Arena stadium;
    Location lobby, hub, podium;
    String worldName = "TournamentWorld";
    boolean loaded;
    private final Set<String> warned = new HashSet<>();

    ArenaManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    File file() { return new File(pl.getDataFolder(), "arenas.yml"); }
    World world() { return Bukkit.getWorld(worldName); }

    /** Loads (or creates) the tournament world, then reads arenas.yml. */
    boolean load() {
        arenas.clear(); stadium = null; loaded = false;
        worldName = pl.settings.str("world.name", "TournamentWorld");
        if (!file().exists()) return false;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file());
        worldName = y.getString("world", worldName);
        World w = ensureWorld(worldName);
        if (w == null) { pl.getLogger().severe("Tournament world '" + worldName + "' could not be loaded."); return false; }
        lobby = Util.loc(w, y.getConfigurationSection("lobby"));
        hub = Util.loc(w, y.getConfigurationSection("hub"));
        podium = Util.loc(w, y.getConfigurationSection("podium"));
        ConfigurationSection as = y.getConfigurationSection("arenas");
        if (as != null) for (String k : as.getKeys(false)) {
            try { arenas.put(Integer.parseInt(k), Arena.from(w, Integer.parseInt(k), false, as.getConfigurationSection(k))); }
            catch (Exception e) { pl.getLogger().warning("Bad arena entry '" + k + "': " + e.getMessage()); }
        }
        if (y.isConfigurationSection("stadium")) stadium = Arena.from(w, 0, true, y.getConfigurationSection("stadium"));
        loaded = lobby != null && hub != null;
        pl.getLogger().info("Loaded " + arenas.size() + " arenas" + (stadium != null ? " + stadium" : "") + " from arenas.yml");
        return loaded;
    }

    static World ensureWorld(String name) {
        World w = Bukkit.getWorld(name);
        if (w != null) return w;
        return new WorldCreator(name).generator(new VoidGenerator()).createWorld();
    }

    void save() {
        YamlConfiguration y = new YamlConfiguration();
        y.set("world", worldName);
        if (lobby != null) y.set("lobby", Util.ser(lobby));
        if (hub != null) y.set("hub", Util.ser(hub));
        if (podium != null) y.set("podium", Util.ser(podium));
        for (Arena a : arenas.values()) y.set("arenas." + a.id, a.toMap());
        if (stadium != null) y.set("stadium", stadium.toMap());
        try { y.save(file()); } catch (IOException e) { pl.getLogger().severe("Cannot save arenas.yml: " + e.getMessage()); }
    }

    /** Enabled & valid arenas, in id order. */
    List<Arena> usable() {
        List<Arena> l = new ArrayList<>();
        for (Arena a : arenas.values()) if (a.problem() == null) l.add(a);
        return l;
    }

    /** Picks a free arena for the given ordinal (stable numbering), or null. Reports broken arenas to admins once. */
    Arena assign(int ordinal) {
        List<Arena> all = new ArrayList<>(arenas.values());
        if (all.isEmpty()) return null;
        List<Arena> order = new ArrayList<>();
        Arena pref = all.get(ordinal % all.size());
        order.add(pref);
        for (Arena a : all) if (a != pref) order.add(a);
        for (Arena a : order) {
            if (!a.free()) continue;
            String prob = a.problem();
            if (prob != null) { reportProblem(a, prob); continue; }
            return a;
        }
        return null;
    }

    Arena stadiumIfFree() {
        if (stadium == null || !stadium.free()) return null;
        String prob = stadium.problem();
        if (prob != null) { reportProblem(stadium, prob); return null; }
        return stadium;
    }

    void reportProblem(Arena a, String prob) {
        if (!warned.add(a.id + ":" + prob)) return;
        String msg = "&c[ArenaTournament] Arena " + a.label() + " is unavailable: " + prob;
        pl.getLogger().warning(Util.plain(msg));
        for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("arenatournament.admin")) p.sendMessage(Util.c(msg));
    }

    List<String> validate() {
        List<String> out = new ArrayList<>();
        if (!loaded) { out.add("&carenas.yml not loaded (build the world with /at setup build)"); return out; }
        if (world() == null) out.add("&cWorld not loaded");
        if (lobby == null || hub == null) out.add("&cLobby or spectator hub missing");
        if (podium == null) out.add("&eNo champion podium set");
        for (Arena a : arenas.values()) { String p = a.problem(); out.add((p == null ? "&a" : "&c") + "Arena " + a.id + " (" + a.name + "): " + (p == null ? "OK" : p)); }
        if (stadium == null) out.add("&eNo stadium defined: semifinals/final will use normal arenas");
        else { String p = stadium.problem(); out.add((p == null ? "&a" : "&c") + "Stadium: " + (p == null ? "OK" : p)); }
        List<Arena> all = new ArrayList<>(arenas.values()); if (stadium != null) all.add(stadium);
        for (int i = 0; i < all.size(); i++) for (int j = i + 1; j < all.size(); j++)
            if (all.get(i).box != null && all.get(j).box != null && all.get(i).box.overlaps(all.get(j).box))
                out.add("&cArenas " + all.get(i).label() + " and " + all.get(j).label() + " overlap!");
        warned.clear();
        return out;
    }

    Arena byId(int id) { return id == 0 ? stadium : arenas.get(id); }
}
