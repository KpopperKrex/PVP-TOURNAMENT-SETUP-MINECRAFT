package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.*;
import java.util.stream.Collectors;

class AtCommand implements CommandExecutor, TabCompleter {
    private final ArenaTournamentPlugin pl;
    AtCommand(ArenaTournamentPlugin pl) { this.pl = pl; }

    private static final List<String> PLAYER = List.of("help", "status", "players", "list", "register", "join", "leave", "bracket", "matches", "spectate", "player");
    private static final List<String> ADMIN = List.of("setup", "start", "pause", "resume", "cancel", "kit", "seed", "reload", "reset", "admin", "forcewin", "forfeit", "setlobby", "arenas", "validate", "history", "replace", "announce", "rematch");

    private boolean isAdmin(CommandSender s) { return s.hasPermission("arenatournament.admin"); }
    private void msg(CommandSender s, String m) { s.sendMessage(Util.c(m)); }
    private void result(CommandSender s, String err, String ok) { msg(s, err == null ? "&a" + ok : "&c" + err); }

    @Override public boolean onCommand(CommandSender s, Command c, String label, String[] a) {
        if (!s.hasPermission("arenatournament.play")) { msg(s, "&cNo permission."); return true; }
        String sub = a.length == 0 ? (s instanceof Player ? "menu" : "help") : a[0].toLowerCase(Locale.ROOT);
        if (ADMIN.contains(sub) && !isAdmin(s)) { msg(s, "&cNo permission."); return true; }
        Player p = s instanceof Player pp ? pp : null;
        TournamentManager tm = pl.tournaments;
        switch (sub) {
            case "menu" -> pl.guis.mainMenu(p);
            case "help" -> help(s);
            case "status" -> { for (String l : pl.displays.statusText().split("\n")) msg(s, l); }
            case "players", "list" -> players(s);
            case "replace" -> replace(s, a);
            case "announce" -> announce(s, a);
            case "rematch" -> rematch(s, a);
            case "register" -> {
                if (a.length >= 2 && isAdmin(s)) {
                    Player t = Bukkit.getPlayerExact(a[1]);
                    if (t == null) { msg(s, "&cPlayer not online."); break; }
                    result(s, tm.register(t.getUniqueId(), t.getName(), true), "Registered " + t.getName() + ".");
                } else if (p != null) pl.guis.registration(p);
                else msg(s, "&cUsage: /at register <player>");
            }
            case "join" -> { if (need(s, p)) result(s, tm.register(p.getUniqueId(), p.getName(), false), "You are registered! (" + (tm.t == null ? 0 : tm.t.players.size()) + "/" + pl.settings.num("tournament.max-players", 24) + ")"); }
            case "leave" -> leave(s, p, a);
            case "bracket" -> { if (need(s, p)) pl.guis.bracket(p, -1); }
            case "matches" -> { if (need(s, p)) pl.guis.liveMatches(p, 0); }
            case "spectate" -> spectate(s, p, a);
            case "player" -> {
                if (!need(s, p)) break;
                if (a.length >= 2 && !isAdmin(s)) { msg(s, "&cNo permission."); break; }
                UUID u = p.getUniqueId();
                if (a.length >= 2) { @SuppressWarnings("deprecation") var op = Bukkit.getOfflinePlayer(a[1]); u = op.getUniqueId(); }
                pl.guis.stats(p, u);
            }
            case "admin" -> { if (need(s, p)) pl.guis.admin(p); }
            case "setup" -> setup(s, p, a);
            case "start" -> result(s, tm.start(), "Tournament started.");
            case "pause" -> result(s, tm.pause(), "Paused.");
            case "resume" -> result(s, tm.resume(), "Resumed.");
            case "cancel" -> {
                if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) msg(s, "&eThis cancels the tournament. Run &f/at cancel confirm&e.");
                else result(s, tm.cancel(), "Tournament cancelled.");
            }
            case "reset" -> {
                if (a.length < 2 || !a[1].equalsIgnoreCase("confirm")) msg(s, "&eThis cancels and clears the current tournament. Run &f/at reset confirm&e.");
                else result(s, tm.reset(), "Tournament reset.");
            }
            case "reload" -> { pl.settings.load(); boolean ok = pl.arenas.load(); msg(s, ok ? "&aConfig and arenas reloaded." : "&eConfig reloaded, but arenas.yml is missing/invalid (/at setup build)."); }
            case "forcewin", "forfeit" -> {
                if (a.length < 2) { msg(s, "&cUsage: /at " + sub + " <player>"); break; }
                @SuppressWarnings("deprecation") var op = Bukkit.getOfflinePlayer(a[1]);
                UUID u = op.getUniqueId();
                if (tm.t != null) for (Map.Entry<UUID, String> e : tm.t.players.entrySet()) if (e.getValue().equalsIgnoreCase(a[1])) u = e.getKey();
                result(s, sub.equals("forcewin") ? tm.forceWin(u) : tm.forfeit(u), "Result applied.");
            }
            case "setlobby" -> {
                if (!need(s, p)) break;
                pl.arenas.lobby = p.getLocation(); pl.arenas.save(); msg(s, "&aLobby set to your position.");
            }
            case "arenas" -> arenas(s, a);
            case "validate" -> { for (String l : pl.arenas.validate()) msg(s, l); }
            case "kit" -> kit(s, p, a);
            case "seed" -> seed(s, a);
            case "history" -> pl.db.history(10, l -> { msg(s, "&6Recent tournaments:"); if (l.isEmpty()) msg(s, "&7none"); l.forEach(x -> msg(s, "&7" + x)); });
            default -> msg(s, "&cUnknown subcommand. Try /at help");
        }
        return true;
    }

    private void players(CommandSender s) {
        Tournament t = pl.tournaments.t;
        if (t == null) { msg(s, "&7No tournament is set up."); return; }
        msg(s, "&6Registered players &7(" + t.players.size() + "/" + pl.settings.num("tournament.max-players", 24) + ") &8- &f" + t.status);
        if (t.players.isEmpty()) { msg(s, "&7Nobody yet. Use /at join."); return; }
        StringBuilder line = new StringBuilder();
        int i = 0;
        for (Map.Entry<UUID, String> e : t.players.entrySet()) {
            UUID u = e.getKey();
            String tag = "";
            if (t.status != Status.REGISTRATION) {
                if (u.equals(t.champion)) tag = " &6[CHAMPION]";
                else if (t.eliminated.contains(u)) tag = " &c[OUT #" + t.placement.getOrDefault(u, 0) + "]";
                else tag = " &a[ALIVE]";
            }
            if (Bukkit.getPlayer(u) == null) tag += " &8(offline)";
            line.append("&7").append(++i).append(". &f").append(e.getValue()).append(tag).append("   ");
            if (i % 3 == 0) { msg(s, line.toString()); line.setLength(0); }
        }
        if (line.length() > 0) msg(s, line.toString());
    }

    private void replace(CommandSender s, String[] a) {
        if (a.length < 3) { msg(s, "&cUsage: /at replace <registered player> <online substitute>"); return; }
        Tournament t = pl.tournaments.t;
        if (t == null) { msg(s, "&cNo tournament."); return; }
        UUID old = null;
        for (Map.Entry<UUID, String> e : t.players.entrySet()) if (e.getValue().equalsIgnoreCase(a[1])) old = e.getKey();
        Player np = Bukkit.getPlayerExact(a[2]);
        if (old == null) { msg(s, "&c" + a[1] + " is not in the tournament."); return; }
        if (np == null) { msg(s, "&cSubstitute must be online."); return; }
        result(s, pl.tournaments.replace(old, np), a[1] + " replaced by " + np.getName() + ".");
    }

    private void announce(CommandSender s, String[] a) {
        if (a.length < 2) { msg(s, "&cUsage: /at announce <message>"); return; }
        String text = String.join(" ", Arrays.copyOfRange(a, 1, a.length));
        Bukkit.getServer().broadcast(Util.c(pl.settings.prefix() + "&e" + text));
        for (Player p : Bukkit.getOnlinePlayers()) { p.sendActionBar(Util.c("&e" + text)); p.playSound(p.getLocation(), org.bukkit.Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.2f); }
    }

    private void rematch(CommandSender s, String[] a) {
        if (a.length < 2) { msg(s, "&cUsage: /at rematch <player in an active match>"); return; }
        Player t = Bukkit.getPlayerExact(a[1]);
        MatchManager.Active am = t == null ? null : pl.matches.of(t.getUniqueId());
        if (am == null) { msg(s, "&cThat player is not in an active match."); return; }
        pl.matches.cancelMatch(am, "admin rematch");
        msg(s, "&aMatch cancelled; it will restart automatically.");
    }

    private boolean need(CommandSender s, Player p) { if (p == null) msg(s, "&cPlayers only."); return p != null; }

    private void help(CommandSender s) {
        msg(s, "&6&lArenaTournament &7commands");
        msg(s, "&e/at &7menu  &e/at status  &e/at players  &e/at join|leave  &e/at register  &e/at bracket  &e/at matches");
        msg(s, "&e/at spectate [player]  &e/at player  &e/at help");
        if (isAdmin(s)) {
            msg(s, "&c/at setup [open|close|reopen|build|worldguard]  &c/at start|pause|resume  &c/at cancel|reset confirm");
            msg(s, "&c/at kit [save|reset|give|mode] &c/at seed [add|remove|list|method]  &c/at forcewin|forfeit <player>");
            msg(s, "&c/at arenas [enable|disable <id>]  &c/at validate  &c/at setlobby  &c/at reload  &c/at admin  &c/at history  &c/at replace <old> <new>  &c/at announce <msg>  &c/at rematch <player>");
        }
    }

    private void leave(CommandSender s, Player p, String[] a) {
        if (!need(s, p)) return;
        TournamentManager tm = pl.tournaments;
        UUID u = p.getUniqueId();
        if (pl.spectators.isTracked(u)) { pl.spectators.leave(p); msg(s, "&aYou left spectator mode."); return; }
        if (tm.t != null && tm.t.status == Status.REGISTRATION && tm.t.players.containsKey(u)) { result(s, tm.unregister(u), "You withdrew from the tournament."); return; }
        if (tm.aliveParticipant(u)) {
            if (a.length >= 2 && a[1].equalsIgnoreCase("confirm")) { result(s, tm.forfeit(u), "You forfeited."); }
            else msg(s, "&eYou are in a running tournament. &f/at leave confirm &ewill forfeit your current match.");
            return;
        }
        if (pl.states.hasSaved(u)) { pl.states.restore(p); msg(s, "&aState restored."); return; }
        msg(s, "&7Nothing to leave.");
    }

    private void spectate(CommandSender s, Player p, String[] a) {
        if (!need(s, p)) return;
        if (a.length >= 2) {
            Player t = Bukkit.getPlayerExact(a[1]);
            if (t == null) { msg(s, "&cPlayer not online."); return; }
            String err = pl.spectators.spectatePlayer(p, t);
            if (err != null) msg(s, "&c" + err);
        } else pl.guis.spectateMenu(p);
    }

    private void setup(CommandSender s, Player p, String[] a) {
        String what = a.length >= 2 ? a[1].toLowerCase(Locale.ROOT) : "";
        TournamentManager tm = pl.tournaments;
        switch (what) {
            case "open" -> result(s, tm.open(), "Registration opened.");
            case "close" -> result(s, tm.closeRegistration(), "Registration closed.");
            case "reopen" -> result(s, tm.openRegistration(), "Registration re-opened.");
            case "build" -> {
                if (a.length < 3 || !a[2].equalsIgnoreCase("confirm")) msg(s, "&eThis (re)builds the tournament world blocks and overwrites arenas.yml. Run &f/at setup build confirm&e.");
                else pl.builder.build(s);
            }
            case "worldguard" -> {
                if (Bukkit.getPluginManager().getPlugin("WorldGuard") == null) { msg(s, "&cWorldGuard is not installed. The built-in protection is active."); break; }
                try { for (String l : WorldGuardHook.createRegions(pl)) msg(s, "&7" + l); }
                catch (Throwable t) { msg(s, "&cWorldGuard hook failed: " + t); }
            }
            default -> {
                msg(s, "&6Setup: &f/at setup open &7(new tournament + registration) | &fclose &7| &freopen &7| &fbuild confirm &7| &fworldguard");
                msg(s, "&7World: " + (pl.arenas.loaded ? "&aloaded (" + pl.arenas.arenas.size() + " arenas)" : "&cnot built") + "  &7Seeding: &f" + pl.settings.str("tournament.seeding", "RANDOM") + "  &7Mode: &f" + pl.kits.mode());
            }
        }
    }

    private void arenas(CommandSender s, String[] a) {
        if (a.length >= 3 && (a[1].equalsIgnoreCase("enable") || a[1].equalsIgnoreCase("disable"))) {
            try {
                Arena ar = pl.arenas.byId(Integer.parseInt(a[2]));
                if (ar == null) { msg(s, "&cNo such arena."); return; }
                if (ar.occupiedBy >= 0) { msg(s, "&cArena is in use right now."); return; }
                ar.enabled = a[1].equalsIgnoreCase("enable"); pl.arenas.save();
                msg(s, "&aArena " + ar.label() + (ar.enabled ? " enabled." : " disabled."));
            } catch (NumberFormatException e) { msg(s, "&cArena id must be a number (0 = stadium)."); }
            return;
        }
        for (Arena ar : pl.arenas.arenas.values()) { String pr = ar.problem(); msg(s, (pr == null ? "&a" : "&c") + ar.id + " &7" + ar.name + " &8(" + ar.theme + ") " + (ar.occupiedBy >= 0 ? "&eIN USE" : pr == null ? "&aFREE" : "&c" + pr)); }
        if (pl.arenas.stadium != null) { String pr = pl.arenas.stadium.problem(); msg(s, (pr == null ? "&a" : "&c") + "0 &7Stadium " + (pr == null ? "&aOK" : "&c" + pr)); }
    }

    private void kit(CommandSender s, Player p, String[] a) {
        String mode = a.length >= 3 ? a[2].toUpperCase() : pl.kits.mode();
        String what = a.length >= 2 ? a[1].toLowerCase() : "";
        switch (what) {
            case "save" -> { if (need(s, p)) msg(s, pl.kits.saveFrom(p, mode) ? "&aSaved your inventory as the " + mode + " kit." : "&cSave failed."); }
            case "reset" -> msg(s, pl.kits.reset(mode) ? "&aReset " + mode + " kit to defaults." : "&cFailed.");
            case "give" -> { if (need(s, p)) pl.kits.apply(p); }
            case "mode" -> { if (a.length < 3) msg(s, "&7Current mode: &f" + pl.kits.mode()); else { pl.settings.set("combat.mode", mode); msg(s, "&aCombat mode: " + mode); } }
            default -> msg(s, "&e/at kit save [MODE] | reset [MODE] | give | mode <STANDARD|CRYSTAL|UHC>  &7(current: " + pl.kits.mode() + ")");
        }
    }

    private void seed(CommandSender s, String[] a) {
        TournamentManager tm = pl.tournaments;
        String what = a.length >= 2 ? a[1].toLowerCase() : "list";
        switch (what) {
            case "method" -> {
                if (a.length < 3 || !List.of("RANDOM", "ADMIN", "LEADERBOARD").contains(a[2].toUpperCase())) { msg(s, "&cUsage: /at seed method <RANDOM|ADMIN|LEADERBOARD>"); return; }
                pl.settings.set("tournament.seeding", a[2].toUpperCase()); msg(s, "&aSeeding method: " + a[2].toUpperCase());
            }
            case "add", "remove" -> {
                if (a.length < 3) { msg(s, "&cUsage: /at seed " + what + " <player>"); return; }
                if (tm.t == null || tm.t.status != Status.REGISTRATION) { msg(s, "&cOnly possible during registration."); return; }
                UUID u = null;
                for (Map.Entry<UUID, String> e : tm.t.players.entrySet()) if (e.getValue().equalsIgnoreCase(a[2])) u = e.getKey();
                if (u == null) { msg(s, "&cThat player is not registered."); return; }
                if (what.equals("add")) { if (!tm.adminByes.contains(u)) tm.adminByes.add(u); } else tm.adminByes.remove(u);
                msg(s, "&aAdmin bye picks: " + tm.adminByes.stream().map(tm.t::nameOf).collect(Collectors.joining(", ")) + (pl.settings.str("tournament.seeding", "RANDOM").equalsIgnoreCase("ADMIN") ? "" : " &e(only used when seeding method is ADMIN)"));
            }
            default -> {
                msg(s, "&6Seeding method: &f" + pl.settings.str("tournament.seeding", "RANDOM"));
                msg(s, "&6Admin picks: &f" + (tm.t == null ? "-" : tm.adminByes.stream().map(tm.t::nameOf).collect(Collectors.joining(", "))));
                if (tm.t != null && !tm.t.seeds.isEmpty()) msg(s, "&6Seeds: &f" + tm.t.seeds.entrySet().stream().sorted(Map.Entry.comparingByValue()).map(e -> e.getValue() + "." + tm.t.nameOf(e.getKey())).collect(Collectors.joining(" ")));
            }
        }
    }

    @Override public List<String> onTabComplete(CommandSender s, Command c, String label, String[] a) {
        List<String> out = new ArrayList<>();
        if (a.length == 1) {
            out.addAll(PLAYER); if (isAdmin(s)) out.addAll(ADMIN);
        } else if (a.length == 2) {
            switch (a[0].toLowerCase()) {
                case "setup" -> out.addAll(List.of("open", "close", "reopen", "build", "worldguard"));
                case "kit" -> out.addAll(List.of("save", "reset", "give", "mode"));
                case "seed" -> out.addAll(List.of("add", "remove", "list", "method"));
                case "arenas" -> out.addAll(List.of("enable", "disable"));
                case "cancel", "reset", "leave" -> out.add("confirm");
                case "register", "spectate", "player", "forcewin", "forfeit", "rematch", "replace" -> Bukkit.getOnlinePlayers().forEach(pp -> out.add(pp.getName()));
            }
        } else if (a.length == 3) {
            switch (a[0].toLowerCase()) {
                case "seed" -> { if (a[1].equalsIgnoreCase("method")) out.addAll(List.of("RANDOM", "ADMIN", "LEADERBOARD")); else Bukkit.getOnlinePlayers().forEach(pp -> out.add(pp.getName())); }
                case "kit" -> out.addAll(List.of("STANDARD", "CRYSTAL", "UHC"));
                case "replace" -> Bukkit.getOnlinePlayers().forEach(pp -> out.add(pp.getName()));
                case "setup" -> out.add("confirm");
                case "arenas" -> pl.arenas.arenas.keySet().forEach(i -> out.add(String.valueOf(i)));
            }
        }
        String last = a[a.length - 1].toLowerCase();
        return out.stream().filter(x -> x.toLowerCase().startsWith(last)).sorted().collect(Collectors.toList());
    }
}
