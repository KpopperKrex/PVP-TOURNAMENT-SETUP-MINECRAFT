package dev.arenatournament;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.*;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.Firework;
import org.bukkit.entity.Player;
import org.bukkit.inventory.meta.FireworkMeta;
import org.bukkit.potion.PotionEffect;

import java.time.Duration;
import java.util.*;

/** Registration, seeding, bracket generation, round progression, lifecycle and crash recovery. */
class TournamentManager {
    private final ArenaTournamentPlugin pl;
    Tournament t;
    final Map<UUID, Stats> stats = new HashMap<>();
    final List<UUID> adminByes = new ArrayList<>();
    private long roundStartAt;
    private int announcedRound = -1;
    private boolean celebrating;
    private final Map<Integer, Long> noShow = new HashMap<>();
    private long lastNoShowWarn;

    TournamentManager(ArenaTournamentPlugin pl) { this.pl = pl; stats.putAll(pl.db.loadStats()); }

    boolean active() { return t != null && t.active(); }
    boolean participant(UUID u) { return t != null && t.players.containsKey(u); }
    boolean aliveParticipant(UUID u) { return active() && t.alive(u); }
    void changed() { if (t != null) pl.db.saveTournament(t); pl.refreshViews(); }

    Stats stat(UUID u, String name) { return stats.computeIfAbsent(u, k -> new Stats(u, name)); }
    private void saveStat(Stats s) { pl.db.saveStats(s); }

    // ================= lifecycle =================
    String open() {
        if (active()) return "A tournament is already in progress (use /at cancel first).";
        t = new Tournament();
        t.id = System.currentTimeMillis();
        t.name = pl.settings.tname();
        t.status = Status.REGISTRATION;
        adminByes.clear(); announcedRound = -1; celebrating = false; noShow.clear();
        pl.settings.bcast("registration-open");
        for (Player p : Bukkit.getOnlinePlayers()) p.playSound(p.getLocation(), Sound.BLOCK_NOTE_BLOCK_PLING, 1f, 1.5f);
        changed();
        return null;
    }

    String closeRegistration() {
        if (t == null || t.status != Status.REGISTRATION) return "No tournament is in registration.";
        t.registrationOpen = false;
        pl.settings.bcast("registration-closed");
        changed();
        return null;
    }

    String openRegistration() {
        if (t == null || t.status != Status.REGISTRATION) return "No tournament is in registration.";
        t.registrationOpen = true; changed(); return null;
    }

    String register(UUID u, String name, boolean admin) {
        if (t == null || t.status != Status.REGISTRATION) return "Registration is not open.";
        if (!t.registrationOpen && !admin) return "Registration is closed.";
        if (t.players.containsKey(u)) return "Already registered.";
        if (t.players.size() >= pl.settings.num("tournament.max-players", 24)) return "The tournament is full.";
        t.players.put(u, name);
        if (pl.settings.bool("tournament.announce-registrations", true))
            Bukkit.getServer().broadcast(Util.c(pl.settings.prefix() + "&f" + name + " &7registered &8(" + t.players.size() + "/" + pl.settings.num("tournament.max-players", 24) + ")"));
        changed();
        return null;
    }

    /** Swap a registered/alive player for a substitute. Seed, bracket slots and admin picks move to the substitute. */
    String replace(UUID old, Player np) {
        if (t == null || !t.active()) return "No active tournament.";
        if (!t.players.containsKey(old)) return "That player is not in the tournament.";
        UUID nu = np.getUniqueId();
        if (t.players.containsKey(nu)) return "The substitute is already registered.";
        boolean running = t.status != Status.REGISTRATION;
        if (running) {
            if (t.eliminated.contains(old)) return "That player is already eliminated.";
            if (pl.matches.of(old) != null) return "Cannot replace a player during their live match (use /at rematch first).";
        }
        List<Map.Entry<UUID, String>> entries = new ArrayList<>(t.players.entrySet());
        t.players.clear();
        for (Map.Entry<UUID, String> e : entries) {
            if (e.getKey().equals(old)) t.players.put(nu, np.getName()); else t.players.put(e.getKey(), e.getValue());
        }
        Integer seed = t.seeds.remove(old); if (seed != null) t.seeds.put(nu, seed);
        Integer place = t.placement.remove(old); if (place != null) t.placement.put(nu, place);
        for (BracketMatch m : t.all()) {
            for (int i = 0; i < 2; i++) if (old.equals(m.p[i])) m.p[i] = nu;
            if (old.equals(m.winner)) m.winner = nu;
        }
        if (old.equals(t.champion)) t.champion = nu;
        int ai = adminByes.indexOf(old); if (ai >= 0) adminByes.set(ai, nu);
        if (running) {
            Player op = Bukkit.getPlayer(old);
            if (op != null) pl.states.restore(op);
            pl.states.ensureSaved(np);
            Stats s = stat(nu, np.getName()); s.tournaments++; saveStat(s);
            sendToIdle(np);
        }
        changed();
        return null;
    }

    String unregister(UUID u) {
        if (t == null || t.status != Status.REGISTRATION) return "You can only withdraw before the tournament starts.";
        if (t.players.remove(u) == null) return "Not registered.";
        adminByes.remove(u);
        changed();
        return null;
    }

    /** Seed order: index 0 = seed 1. Seeds near the top receive the first-round byes. */
    private List<UUID> seedOrder() {
        String method = pl.settings.str("tournament.seeding", "RANDOM").toUpperCase();
        List<UUID> rest = new ArrayList<>(t.players.keySet());
        List<UUID> out = new ArrayList<>();
        if (method.equals("ADMIN")) for (UUID u : adminByes) if (rest.remove(u)) out.add(u);
        Collections.shuffle(rest);
        if (method.equals("LEADERBOARD")) {
            rest.sort(Comparator.comparingInt((UUID u) -> score(u)).reversed());
        }
        out.addAll(rest);
        return out;
    }
    private int score(UUID u) { Stats s = stats.get(u); return s == null ? 0 : s.titles * 1000 + s.wins * 10 - s.losses; }

    static int[] seedPositions(int pool) {
        int[] a = {1, 2};
        while (a.length < pool) {
            int n = a.length * 2; int[] b = new int[n];
            for (int i = 0; i < a.length; i++) { b[2 * i] = a[i]; b[2 * i + 1] = n + 1 - a[i]; }
            a = b;
        }
        return a;
    }

    String start() {
        if (t == null || t.status != Status.REGISTRATION) return "No tournament is in registration.";
        int n = t.players.size();
        int min = Math.max(2, pl.settings.num("tournament.min-players-to-start", pl.settings.num("tournament.max-players", 24)));
        if (n < min) return "Need at least " + min + " players (have " + n + ").";
        if (!pl.arenas.loaded) return "The tournament world is not set up. Run /at setup build.";
        if (pl.arenas.usable().isEmpty()) return "No usable arena. Run /at validate.";
        List<String> offline = new ArrayList<>();
        for (Map.Entry<UUID, String> e : t.players.entrySet()) if (Bukkit.getPlayer(e.getKey()) == null) offline.add(e.getValue());
        if (!offline.isEmpty()) return "These registered players are offline: " + String.join(", ", offline);

        t.registrationOpen = false;
        List<UUID> order = seedOrder();
        buildBracket(order);
        t.status = Status.RUNNING; t.startedAt = System.currentTimeMillis(); t.currentRound = 0; announcedRound = -1;
        int byes = t.poolSize - n;
        if (byes != pl.settings.num("tournament.first-round-byes", 8))
            pl.getLogger().info("Bracket has " + byes + " byes (config first-round-byes=" + pl.settings.num("tournament.first-round-byes", 8) + " is informational).");
        for (UUID u : order) {
            Player p = Bukkit.getPlayer(u);
            pl.states.ensureSaved(p);
            Stats s = stat(u, t.nameOf(u)); s.tournaments++; saveStat(s);
            sendToIdle(p);
            p.showTitle(Title.title(Util.c("&6&l" + pl.settings.tname()), Util.c("&eThe tournament begins!")));
        }
        roundStartAt = System.currentTimeMillis() + pl.settings.num("tournament.first-round-delay-seconds", 10) * 1000L;
        pl.settings.bcast("tournament-start", "%players%", String.valueOf(n));
        changed();
        return null;
    }

    private void buildBracket(List<UUID> order) {
        int n = order.size(), pool = 2;
        while (pool < n) pool <<= 1;
        t.poolSize = pool; t.rounds.clear(); t.seeds.clear();
        for (int i = 0; i < n; i++) t.seeds.put(order.get(i), i + 1);
        int rounds = Integer.numberOfTrailingZeros(pool), id = 1;
        for (int r = 0; r < rounds; r++) {
            List<BracketMatch> l = new ArrayList<>();
            for (int i = 0; i < (pool >> (r + 1)); i++) l.add(new BracketMatch(id++, r, i));
            t.rounds.add(l);
        }
        int[] pos = seedPositions(pool);
        for (BracketMatch m : t.rounds.get(0)) {
            int a = pos[2 * m.index], b = pos[2 * m.index + 1];
            m.p[0] = a <= n ? order.get(a - 1) : null;
            m.p[1] = b <= n ? order.get(b - 1) : null;
        }
        for (BracketMatch m : t.rounds.get(0)) {
            if (m.p[0] == null || m.p[1] == null) {
                m.bye = true; m.winner = m.p[0] != null ? m.p[0] : m.p[1]; m.state = MState.FINISHED; m.reason = "BYE";
                propagate(m);
            }
        }
    }

    private void propagate(BracketMatch m) {
        if (m.round + 1 < t.rounds.size()) t.rounds.get(m.round + 1).get(m.index / 2).p[m.index % 2] = m.winner;
    }

    String pause() { if (t == null || t.status != Status.RUNNING) return "Tournament is not running."; t.status = Status.PAUSED; pl.settings.bcast("tournament-paused"); changed(); return null; }
    String resume() {
        if (t == null || t.status != Status.PAUSED) return "Tournament is not paused.";
        t.status = Status.RUNNING; roundStartAt = System.currentTimeMillis() + 5000; pl.settings.bcast("tournament-resumed"); changed(); return null;
    }

    String cancel() {
        if (!active()) return "No active tournament.";
        pl.matches.cancelAll();
        t.status = Status.CANCELLED; t.endedAt = System.currentTimeMillis();
        pl.settings.bcast("tournament-cancelled");
        restoreEveryone();
        changed();
        return null;
    }

    String reset() {
        if (active()) { String e = cancel(); if (e != null) return e; }
        t = null; adminByes.clear(); celebrating = false;
        pl.refreshViews();
        return null;
    }

    void restoreEveryone() {
        Set<UUID> ids = new HashSet<>(pl.states.savedIds());
        for (UUID u : ids) { Player p = Bukkit.getPlayer(u); if (p != null) pl.states.restore(p); }
        pl.spectators.clear();
        for (Arena a : pl.arenas.arenas.values()) a.occupiedBy = -1;
        if (pl.arenas.stadium != null) pl.arenas.stadium.occupiedBy = -1;
    }

    // ================= per-second tick =================
    void tick() {
        if (t == null || t.status != Status.RUNNING) return;
        int r = -1;
        for (int i = 0; i < t.rounds.size() && r < 0; i++) for (BracketMatch m : t.rounds.get(i)) if (!m.done()) { r = i; break; }
        if (r < 0) { finishTournament(); return; }
        if (announcedRound != r) {
            announcedRound = r; t.currentRound = r;
            if (r > 0 || System.currentTimeMillis() < roundStartAt) {
                if (r > 0) roundStartAt = System.currentTimeMillis() + pl.settings.num("tournament.round-delay-seconds", 15) * 1000L;
            }
            announceRound(r);
            changed();
        }
        if (System.currentTimeMillis() < roundStartAt) return;
        scheduleMatches(r);
    }

    private void announceRound(int r) {
        String name = t.roundName(r);
        pl.settings.bcast("round-start", "%round%", name);
        boolean big = (t.poolSize >> r) <= 4;
        for (Player p : Bukkit.getOnlinePlayers()) {
            if (!inTournamentView(p)) continue;
            p.showTitle(Title.title(Util.c((big ? "&c&l" : "&6&l") + name), Util.c("&7Get ready!"), Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(3), Duration.ofMillis(500))));
            p.playSound(p.getLocation(), big ? Sound.ENTITY_ENDER_DRAGON_GROWL : Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
    }

    boolean inTournamentView(Player p) {
        return participant(p.getUniqueId()) || pl.spectators.isTracked(p.getUniqueId()) || (pl.arenas.world() != null && p.getWorld().equals(pl.arenas.world()));
    }

    private void scheduleMatches(int r) {
        List<String> stadiumRounds = pl.settings.list("matches.stadium-rounds");
        boolean useStadium = pl.arenas.stadium != null && stadiumRounds.contains(t.roundKey(r));
        int cap = Math.max(1, pl.settings.num("matches.simultaneous-matches", 8));
        int ordinal = 0;
        for (BracketMatch m : t.rounds.get(r)) {
            if (m.bye) continue;
            int ord = ordinal++;
            if (m.done() || m.state != MState.WAITING || m.p[0] == null || m.p[1] == null) continue;
            if (pl.matches.running() >= cap) break;
            Player a = Bukkit.getPlayer(m.p[0]), b = Bukkit.getPlayer(m.p[1]);
            if (a == null || b == null) { handleAbsent(m, a, b); continue; }
            noShow.remove(m.id);
            Arena ar = useStadium ? pl.arenas.stadiumIfFree() : pl.arenas.assign(ord);
            if (ar == null) continue;
            pl.matches.start(m, ar);
        }
    }

    private void handleAbsent(BracketMatch m, Player a, Player b) {
        long now = System.currentTimeMillis();
        long since = noShow.computeIfAbsent(m.id, k -> now);
        long limit = pl.settings.num("matches.no-show-forfeit-seconds", 120) * 1000L;
        if (now - since < limit) return;
        if (a == null && b == null) {
            if (now - lastNoShowWarn > 60000) { lastNoShowWarn = now; notifyAdmins("&cMatch #" + m.id + " (" + t.nameOf(m.p[0]) + " vs " + t.nameOf(m.p[1]) + "): both players offline. Resolve with /at forcewin or /at forfeit."); }
            return;
        }
        UUID loser = a == null ? m.p[0] : m.p[1];
        resolveWithoutPlay(m, m.other(loser), loser, "NO-SHOW", true);
    }

    void notifyAdmins(String msg) {
        pl.getLogger().warning(Util.plain(msg));
        for (Player p : Bukkit.getOnlinePlayers()) if (p.hasPermission("arenatournament.admin")) p.sendMessage(Util.c(msg));
    }

    // ================= results =================
    void resolveWithoutPlay(BracketMatch m, UUID winner, UUID loser, String reason, boolean forfeit) {
        if (m.done()) return;
        m.state = MState.FINISHED;
        matchFinished(m, winner, loser, reason, forfeit);
    }

    /** Called exactly once per match (MatchManager guards duplicates). */
    void matchFinished(BracketMatch m, UUID winner, UUID loser, String reason, boolean forfeit) {
        if (m.done()) return;
        m.winner = winner; m.reason = reason; m.state = MState.FINISHED;
        t.eliminated.add(loser);
        int place = (t.poolSize >> m.round) / 2 + 1;
        t.placement.put(loser, place);
        Stats w = stat(winner, t.nameOf(winner)), l = stat(loser, t.nameOf(loser));
        w.matches++; w.wins++; l.matches++; l.losses++;
        if (forfeit) l.forfeits++;
        if (l.best == 0 || place < l.best) l.best = place;
        saveStat(w); saveStat(l);
        Arena ar = pl.arenas.byId(m.arenaId < 0 ? -1 : m.arenaId);
        pl.settings.bcastRaw("match-result", "%arena%", ar == null ? "-" : ar.label(), "%winner%", t.nameOf(winner), "%loser%", t.nameOf(loser), "%reason%", reason);
        propagate(m);
        if (m.round == t.rounds.size() - 1) { t.champion = winner; t.placement.put(winner, 1); }
        changed();
    }

    private void finishTournament() {
        BracketMatch last = t.rounds.get(t.rounds.size() - 1).get(0);
        if (!last.done() || t.champion == null) {
            t.status = Status.PAUSED;
            notifyAdmins("&cTournament data is inconsistent (final has no winner). Paused - use /at forcewin <player>.");
            changed(); return;
        }
        t.status = Status.FINISHED; t.endedAt = System.currentTimeMillis();
        Stats cs = stat(t.champion, t.nameOf(t.champion)); cs.titles++; cs.best = 1; saveStat(cs);
        String champ = t.nameOf(t.champion);
        pl.settings.bcast("champion", "%player%", champ);
        runPrizes(last);
        for (Player p : Bukkit.getOnlinePlayers()) {
            p.showTitle(Title.title(Util.c("&6&lCHAMPION"), Util.c("&e" + champ), Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(6), Duration.ofSeconds(1))));
            p.playSound(p.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1f, 1f);
        }
        celebrating = true;
        changed();
        long delay = Math.max(2, pl.settings.num("matches.post-match-seconds", 4) + 2) * 20L;
        Bukkit.getScheduler().runTaskLater(pl, this::celebrate, delay);
        Bukkit.getScheduler().runTaskLater(pl, this::endCelebration, delay + pl.settings.num("tournament.celebration-seconds", 30) * 20L);
    }

    private void runPrizes(BracketMatch last) {
        if (!pl.settings.bool("prizes.enabled", false)) return;
        runCommands(pl.settings.list("prizes.champion"), t.nameOf(t.champion), "1");
        UUID ru = last.loser();
        if (ru != null) runCommands(pl.settings.list("prizes.runner-up"), t.nameOf(ru), "2");
    }

    private void runCommands(List<String> cmds, String player, String place) {
        for (String c : cmds) {
            String cmd = (c.startsWith("/") ? c.substring(1) : c).replace("%player%", player).replace("%place%", place);
            Bukkit.dispatchCommand(Bukkit.getConsoleSender(), cmd);
        }
    }

    private void celebrate() {
        Player c = Bukkit.getPlayer(t.champion);
        if (c != null && pl.arenas.podium != null) {
            c.setGameMode(GameMode.ADVENTURE); c.teleport(pl.arenas.podium);
            Location base = pl.arenas.podium.clone();
            for (int i = 0; i < 6; i++) {
                final int k = i;
                Bukkit.getScheduler().runTaskLater(pl, () -> {
                    Location l = base.clone().add((k - 3) * 2, 0, 0);
                    Firework fw = l.getWorld().spawn(l, Firework.class);
                    FireworkMeta fm = fw.getFireworkMeta();
                    fm.addEffect(FireworkEffect.builder().withColor(Color.YELLOW, Color.ORANGE).with(FireworkEffect.Type.BALL_LARGE).flicker(true).build());
                    fm.setPower(1); fw.setFireworkMeta(fm);
                }, i * 10L);
            }
        }
    }

    private void endCelebration() {
        if (!celebrating) return;
        celebrating = false;
        restoreEveryone();
        pl.refreshViews();
    }

    // ================= admin resolution =================
    String forceWin(UUID u) { return resolve(u, true); }
    String forfeit(UUID u) { return resolve(u, false); }
    private String resolve(UUID u, boolean winnerIsU) {
        if (t == null || t.status == Status.REGISTRATION || !t.active()) return "No running tournament.";
        BracketMatch m = t.currentMatch(u);
        if (m == null || m.p[0] == null || m.p[1] == null) return "That player has no resolvable match right now.";
        UUID w = winnerIsU ? u : m.other(u), l = m.other(w);
        MatchManager.Active am = pl.matches.ofMatch(m.id);
        if (am != null) pl.matches.finish(am, w, l, winnerIsU ? "ADMIN" : "FORFEIT", !winnerIsU);
        else resolveWithoutPlay(m, w, l, winnerIsU ? "ADMIN" : "FORFEIT", !winnerIsU);
        return null;
    }

    // ================= player placement =================
    void clearPlayer(Player p) {
        p.closeInventory();
        p.getInventory().clear();
        for (PotionEffect e : new ArrayList<>(p.getActivePotionEffects())) p.removePotionEffect(e.getType());
        p.setHealth(p.getAttribute(Attribute.MAX_HEALTH).getValue());
        p.setFoodLevel(20); p.setSaturation(20f); p.setFireTicks(0); p.setFallDistance(0); p.setExp(0); p.setLevel(0);
    }

    /** Lobby (adventure) for living participants; hub (spectator) for everyone else. */
    void sendToIdle(Player p) {
        clearPlayer(p);
        boolean alive = aliveParticipant(p.getUniqueId());
        if (alive && pl.arenas.lobby != null) { p.setGameMode(GameMode.ADVENTURE); p.setAllowFlight(false); p.teleport(pl.arenas.lobby); }
        else if (pl.arenas.hub != null) { p.setGameMode(GameMode.SPECTATOR); p.teleport(pl.arenas.hub); }
    }

    /** Called when a match releases a player. */
    void afterMatch(Player p) {
        UUID u = p.getUniqueId();
        boolean elim = participant(u) && t.eliminated.contains(u);
        if (elim && pl.settings.bool("players.restore-eliminated-immediately", false) && t.status != Status.FINISHED) pl.states.restore(p);
        else sendToIdle(p);
    }

    /** Join handling: recovery of saved states and reconnects. */
    void onJoin(Player p) {
        UUID u = p.getUniqueId();
        MatchManager.Active am = pl.matches.of(u);
        if (am != null && am.grace.containsKey(u)) { pl.matches.rejoin(am, p); return; }
        if (!pl.states.hasSaved(u)) return;
        boolean inTourney = t != null && (t.status == Status.RUNNING || t.status == Status.PAUSED) && participant(u);
        if (inTourney) {
            boolean elim = t.eliminated.contains(u);
            if (elim && pl.settings.bool("players.restore-eliminated-immediately", false)) pl.states.restore(p);
            else sendToIdle(p);
        } else if (!celebrating) pl.states.restore(p);
    }

    // ================= crash recovery =================
    void recover() {
        Tournament loaded = pl.db.loadActive();
        if (loaded == null) return;
        t = loaded;
        int fixed = 0;
        for (BracketMatch m : t.all()) {
            if (!m.done() && (m.state == MState.COUNTDOWN || m.state == MState.RUNNING || m.state == MState.RESETTING)) { m.state = MState.WAITING; m.arenaId = -1; fixed++; }
            else if (m.done()) m.state = MState.FINISHED;
        }
        if (t.status == Status.RUNNING) t.status = Status.PAUSED;
        announcedRound = -1;
        String msg = "&e[ArenaTournament] Recovered unfinished tournament #" + t.id + " (" + t.status + ", " + t.players.size() + " players, "
                + fixed + " interrupted match" + (fixed == 1 ? "" : "es") + " reset to WAITING). No results were guessed. Use &f/at resume&e to continue or &f/at cancel&e.";
        pl.getLogger().warning(Util.plain(msg));
        Bukkit.getScheduler().runTaskLater(pl, () -> notifyAdmins(msg), 100L);
    }
}
