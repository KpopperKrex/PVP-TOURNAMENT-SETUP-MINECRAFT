package dev.arenatournament;

import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;

/** Kits are stored per mode in kits/<MODE>.yml. Use /at kit save to overwrite one with your inventory. */
class KitManager {
    private final ArenaTournamentPlugin pl;
    private final File dir;

    KitManager(ArenaTournamentPlugin pl) {
        this.pl = pl;
        dir = new File(pl.getDataFolder(), "kits");
        dir.mkdirs();
        for (String m : new String[]{"STANDARD", "CRYSTAL", "UHC"}) {
            File f = new File(dir, m + ".yml");
            if (!f.exists()) write(m, defaults(m));
        }
    }

    String mode() { return pl.settings.str("combat.mode", "STANDARD").toUpperCase(); }

    void apply(Player p) {
        p.getInventory().clear();
        for (Map.Entry<Integer, ItemStack> e : load(mode()).entrySet()) p.getInventory().setItem(e.getKey(), e.getValue().clone());
    }

    Map<Integer, ItemStack> load(String mode) {
        File f = new File(dir, mode + ".yml");
        if (!f.exists()) return defaults(mode);
        YamlConfiguration y = YamlConfiguration.loadConfiguration(f);
        ConfigurationSection s = y.getConfigurationSection("slots");
        Map<Integer, ItemStack> m = new LinkedHashMap<>();
        if (s == null) return defaults(mode);
        for (String k : s.getKeys(false)) {
            ItemStack it = s.getItemStack(k);
            try { if (it != null) m.put(Integer.parseInt(k), it); } catch (NumberFormatException ignored) {}
        }
        return m;
    }

    boolean saveFrom(Player p, String mode) {
        Map<Integer, ItemStack> m = new LinkedHashMap<>();
        ItemStack[] c = p.getInventory().getContents();
        for (int i = 0; i < c.length; i++) if (c[i] != null && c[i].getType() != Material.AIR) m.put(i, c[i]);
        return write(mode, m);
    }

    boolean reset(String mode) { return write(mode, defaults(mode)); }

    private boolean write(String mode, Map<Integer, ItemStack> kit) {
        YamlConfiguration y = new YamlConfiguration();
        y.options().header("Slots: 0-8 hotbar, 9-35 inventory, 36 boots, 37 leggings, 38 chestplate, 39 helmet, 40 offhand");
        for (Map.Entry<Integer, ItemStack> e : kit.entrySet()) y.set("slots." + e.getKey(), e.getValue());
        try { y.save(new File(dir, mode + ".yml")); return true; } catch (IOException e) { pl.getLogger().warning("Kit save failed: " + e.getMessage()); return false; }
    }

    private static ItemStack ench(Material m, Enchantment e, int lvl) { ItemStack i = new ItemStack(m); i.addUnsafeEnchantment(e, lvl); return i; }

    Map<Integer, ItemStack> defaults(String mode) {
        Map<Integer, ItemStack> d = new LinkedHashMap<>();
        switch (mode) {
            case "CRYSTAL" -> {
                d.put(0, new ItemStack(Material.NETHERITE_SWORD));
                d.put(1, new ItemStack(Material.END_CRYSTAL, 64));
                d.put(2, new ItemStack(Material.OBSIDIAN, 64));
                d.put(3, new ItemStack(Material.GOLDEN_APPLE, 16));
                d.put(4, new ItemStack(Material.ENDER_PEARL, 8));
                d.put(36, ench(Material.NETHERITE_BOOTS, Enchantment.PROTECTION, 4));
                d.put(37, ench(Material.NETHERITE_LEGGINGS, Enchantment.PROTECTION, 4));
                d.put(38, ench(Material.NETHERITE_CHESTPLATE, Enchantment.PROTECTION, 4));
                d.put(39, ench(Material.NETHERITE_HELMET, Enchantment.PROTECTION, 4));
            }
            case "UHC" -> {
                d.put(0, new ItemStack(Material.IRON_SWORD));
                d.put(1, new ItemStack(Material.BOW));
                d.put(2, new ItemStack(Material.GOLDEN_APPLE, 6));
                d.put(3, new ItemStack(Material.COOKED_BEEF, 16));
                d.put(4, new ItemStack(Material.COBBLESTONE, 64));
                d.put(5, new ItemStack(Material.FISHING_ROD));
                d.put(9, new ItemStack(Material.ARROW, 32));
                d.put(36, new ItemStack(Material.IRON_BOOTS));
                d.put(37, new ItemStack(Material.IRON_LEGGINGS));
                d.put(38, new ItemStack(Material.IRON_CHESTPLATE));
                d.put(39, new ItemStack(Material.IRON_HELMET));
            }
            default -> {
                d.put(0, new ItemStack(Material.DIAMOND_SWORD));
                d.put(1, new ItemStack(Material.BOW));
                d.put(2, new ItemStack(Material.GOLDEN_APPLE, 5));
                d.put(3, new ItemStack(Material.COOKED_BEEF, 16));
                d.put(9, new ItemStack(Material.ARROW, 24));
                d.put(36, new ItemStack(Material.DIAMOND_BOOTS));
                d.put(37, new ItemStack(Material.DIAMOND_LEGGINGS));
                d.put(38, new ItemStack(Material.DIAMOND_CHESTPLATE));
                d.put(39, new ItemStack(Material.DIAMOND_HELMET));
                d.put(40, new ItemStack(Material.SHIELD));
            }
        }
        return d;
    }
}
