package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.entity.Player;

import java.util.*;

class SpectatorManager {
    private final ArenaTournamentPlugin pl;
    /** player -> match being watched (-1 = in the hub). */
    private final Map<UUID, Integer> watching = new HashMap<>();
    /** non-participants we put into spectator mode (their state is saved and restored on leave). */
    private final Set<UUID> tracked = new HashSet<>();

    SpectatorManager(ArenaTournamentPlugin pl) { this.pl = pl; }

    boolean isTracked(UUID u) { return tracked.contains(u) || watching.containsKey(u); }
    boolean isSpectating(UUID u) { return watching.containsKey(u); }
    void clear() { watching.clear(); tracked.clear(); }
    void forget(Player p) { watching.remove(p.getUniqueId()); }

    String spectate(Player p, MatchManager.Active am) {
        if (!pl.settings.bool("spectators.enabled", true)) return "Spectating is disabled.";
        if (!pl.arenas.loaded) return "Tournament world is not set up.";
        if (pl.matches.of(p.getUniqueId()) != null) return "You cannot spectate while in a match.";
        if (am == null || am.ended || pl.matches.ofMatch(am.bm.id) != am || (am.bm.state != MState.COUNTDOWN && am.bm.state != MState.RUNNING)) return "That match is not active.";
        if (am.arena.problem() != null) return "That arena is unavailable.";
        pl.states.ensureSaved(p);
        if (!pl.tournaments.participant(p.getUniqueId())) tracked.add(p.getUniqueId());
        p.closeInventory();
        p.setGameMode(GameMode.SPECTATOR);
        p.teleport(am.arena.spectate);
        watching.put(p.getUniqueId(), am.bm.id);
        return null;
    }

    String spectatePlayer(Player p, Player target) {
        MatchManager.Active am = pl.matches.of(target.getUniqueId());
        return am == null ? target.getName() + " is not in an active match." : spectate(p, am);
    }

    /** Leaves spectator mode. */
    void leave(Player p) {
        UUID u = p.getUniqueId();
        watching.remove(u);
        boolean wasTracked = tracked.remove(u);
        if (wasTracked || !pl.tournaments.participant(u)) { pl.states.restore(p); return; }
        pl.tournaments.afterMatch(p);
    }

    /** Moves watchers back to the hub (or lobby for living participants) when their match ends. */
    void matchEnded(int matchId) {
        for (Map.Entry<UUID, Integer> e : new ArrayList<>(watching.entrySet())) {
            if (e.getValue() != matchId) continue;
            Player p = Bukkit.getPlayer(e.getKey());
            if (p == null) { watching.remove(e.getKey()); continue; }
            pl.tournaments.sendToIdle(p);
            watching.put(e.getKey(), -1);
        }
    }

    /** Players who are in the watching map but in the hub (not a live match). */
    boolean watchesLive(UUID u) { Integer m = watching.get(u); return m != null && m >= 0; }
}
