package dev.arenatournament;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.*;
import org.bukkit.event.player.*;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;
import org.bukkit.inventory.ItemStack;

import java.util.List;
import java.util.Locale;

/** Combat, results, freezing, disconnects, restrictions. */
class MatchListener implements Listener {
    private final ArenaTournamentPlugin pl;
    MatchListener(ArenaTournamentPlugin pl) { this.pl = pl; }

    private MatchManager.Active am(Entity e) { return e instanceof Player p ? pl.matches.of(p.getUniqueId()) : null; }
    private boolean inWorld(Entity e) { return pl.arenas.world() != null && e.getWorld().equals(pl.arenas.world()); }
    private static boolean totem(Player p) {
        return p.getInventory().getItemInMainHand().getType() == Material.TOTEM_OF_UNDYING || p.getInventory().getItemInOffHand().getType() == Material.TOTEM_OF_UNDYING;
    }

    @EventHandler public void onJoin(PlayerJoinEvent e) {
        Player p = e.getPlayer();
        Bukkit.getScheduler().runTaskLater(pl, () -> { if (p.isOnline()) pl.tournaments.onJoin(p); }, 5L);
    }

    @EventHandler public void onQuit(PlayerQuitEvent e) {
        Player p = e.getPlayer();
        pl.matches.disconnect(p);
        pl.matches.frozen.remove(p.getUniqueId());
        pl.sidebar.remove(p);
    }

    /** Damage: lobby is safe, countdown/finished matches are safe, only the two fighters can hurt each other. */
    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageEvent e) {
        if (!(e.getEntity() instanceof Player p)) return;
        MatchManager.Active am = am(p);
        if (am == null) { if (inWorld(p)) e.setCancelled(true); return; }
        if (am.ended || am.bm.state != MState.RUNNING) { e.setCancelled(true); return; }
        if (e instanceof EntityDamageByEntityEvent be) {
            Entity d = be.getDamager();
            if (d instanceof Projectile pr && pr.getShooter() instanceof Entity s) d = s;
            if (d instanceof Player dp) {
                if (pl.matches.of(dp.getUniqueId()) != am) { e.setCancelled(true); return; }      // cross-arena / spectator
            }
        }
        if (p.getHealth() - e.getFinalDamage() <= 0 && !totem(p)) {
            e.setCancelled(true);
            pl.matches.death(am, p);
        }
    }

    /** Fallback if a death still happens (e.g. a totem that failed). */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onDeath(PlayerDeathEvent e) {
        Player p = e.getEntity();
        MatchManager.Active am = am(p);
        if (am == null) return;
        e.setKeepInventory(true); e.getDrops().clear(); e.setKeepLevel(true); e.setDroppedExp(0); e.deathMessage(null);
        pl.matches.death(am, p);
    }

    @EventHandler public void onRespawn(PlayerRespawnEvent e) {
        Player p = e.getPlayer();
        if (pl.tournaments.participant(p.getUniqueId()) && pl.arenas.hub != null) {
            e.setRespawnLocation(pl.arenas.hub);
            Bukkit.getScheduler().runTaskLater(pl, () -> pl.tournaments.afterMatch(p), 2L);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onRegen(EntityRegainHealthEvent e) {
        if (!(e.getEntity() instanceof Player p) || am(p) == null) return;
        boolean regen = pl.settings.bool("combat.natural-regeneration", true) && !pl.kits.mode().equals("UHC");
        if (!regen && (e.getRegainReason() == EntityRegainHealthEvent.RegainReason.SATIATED || e.getRegainReason() == EntityRegainHealthEvent.RegainReason.REGEN)) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onFood(FoodLevelChangeEvent e) {
        if (!(e.getEntity() instanceof Player p) || !inWorld(p)) return;
        MatchManager.Active a = am(p);
        if (a == null || a.bm.state != MState.RUNNING || !pl.settings.bool("combat.hunger", true)) e.setCancelled(true);
    }

    /** Freeze during countdown and keep fighters inside the arena. */
    @EventHandler(ignoreCancelled = true)
    public void onMove(PlayerMoveEvent e) {
        Player p = e.getPlayer();
        Location to = e.getTo(), from = e.getFrom();
        if (pl.matches.frozen.contains(p.getUniqueId())) {
            if (from.getX() != to.getX() || from.getZ() != to.getZ() || to.getY() > from.getY()) { Location l = from.clone(); l.setYaw(to.getYaw()); l.setPitch(to.getPitch()); e.setTo(l); }
            return;
        }
        MatchManager.Active am = am(p);
        if (am == null || am.ended || am.bm.state != MState.RUNNING) return;
        if (from.getBlockX() == to.getBlockX() && from.getBlockY() == to.getBlockY() && from.getBlockZ() == to.getBlockZ()) return;
        if (to.getY() < am.arena.box.getMinY() - 5) { pl.matches.death(am, p); return; }
        if (!am.arena.contains(to)) e.setTo(from);
    }

    @EventHandler(ignoreCancelled = true)
    public void onTeleport(PlayerTeleportEvent e) {
        Player p = e.getPlayer();
        TeleportCause c = e.getCause();
        MatchManager.Active am = am(p);
        if (am != null && !am.ended && (c == TeleportCause.COMMAND || c == TeleportCause.ENDER_PEARL || c == TeleportCause.CHORUS_FRUIT || c == TeleportCause.SPECTATE)) {
            if (c == TeleportCause.COMMAND || e.getTo() == null || !am.arena.contains(e.getTo())) e.setCancelled(true);
            return;
        }
        if (c == TeleportCause.SPECTATE && pl.spectators.isTracked(p.getUniqueId()) && !p.hasPermission("arenatournament.bypass")) e.setCancelled(true);
        if (c == TeleportCause.COMMAND && inWorld(p) && pl.tournaments.participant(p.getUniqueId()) && !p.hasPermission("arenatournament.bypass")) e.setCancelled(true);
    }

    @EventHandler(ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent e) {
        Player p = e.getPlayer();
        if (p.hasPermission("arenatournament.bypass") || !pl.settings.bool("combat.block-commands-for-participants", true)) return;
        if (am(p) == null) return;
        String cmd = e.getMessage().substring(1).split(" ")[0].toLowerCase(Locale.ROOT);
        if (cmd.contains(":")) cmd = cmd.substring(cmd.indexOf(':') + 1);
        for (String a : pl.settings.list("combat.allowed-commands")) if (a.equalsIgnoreCase(cmd)) return;
        e.setCancelled(true);
        p.sendMessage(Util.c("&cCommands are disabled during your match."));
    }

    @EventHandler(ignoreCancelled = true)
    public void onInteract(PlayerInteractEvent e) {
        if (e.getAction() == Action.PHYSICAL) { if (inWorld(e.getPlayer())) e.setCancelled(true); return; }
        Player p = e.getPlayer();
        MatchManager.Active am = am(p);
        if (am == null) return;
        if (am.bm.state != MState.RUNNING) { e.setCancelled(true); return; }
        ItemStack it = e.getItem();
        if (it == null) return;
        List<String> disabled = pl.settings.list("combat.disabled-items");
        for (String s : disabled) if (s.equalsIgnoreCase(it.getType().name())) { e.setCancelled(true); p.sendMessage(Util.c("&cThat item is disabled in tournament matches.")); return; }
    }

    @EventHandler(ignoreCancelled = true)
    public void onLaunch(ProjectileLaunchEvent e) {
        if (!(e.getEntity().getShooter() instanceof Player p)) return;
        MatchManager.Active am = am(p);
        if (am != null && am.bm.state != MState.RUNNING) e.setCancelled(true);
    }
}
