package dev.arenatournament;

import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.generator.ChunkGenerator;

import java.util.Random;

/** Generates completely empty chunks (void). The WorldBuilder places all structures on top. */
class VoidGenerator extends ChunkGenerator {
    @Override public Location getFixedSpawnLocation(World world, Random random) { return new Location(world, 0.5, 101, 0.5); }
}
