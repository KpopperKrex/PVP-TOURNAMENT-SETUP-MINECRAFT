rootProject.name = "ArenaTournament"
