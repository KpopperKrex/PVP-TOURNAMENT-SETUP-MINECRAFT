# ArenaTournament (Paper 1.21.11) - UNCOMPILED, UNTESTED SOURCE

Status: full source for the plugin. It has NOT been compiled or run on a server. Expect a few compile errors on the first build.

## Build
1. Install JDK 21 and Gradle 8.x (the Gradle wrapper is not included).
2. In this folder run `gradle wrapper` once, then `./gradlew build`.
3. The jar is `build/libs/ArenaTournament-1.0.0.jar`.
   If the WorldGuard dependency versions do not resolve, change them in `build.gradle.kts`.

## Install
1. Put the jar in `plugins/` on a Paper 1.21.11 server. Start the server.
2. On first start the plugin builds `TournamentWorld` (lobby, 8 arenas, stadium, hub, podium) and writes `plugins/ArenaTournament/arenas.yml`.
   Wait for "Tournament world built" in the console. Then run `/at validate`.
3. Edit `plugins/ArenaTournament/config.yml` (branding.*), then `/at reload`.
4. Optional, if WorldGuard is installed: `/at setup worldguard`. It only creates `at_*` regions and never touches your others.

## Running a tournament
`/at setup open` -> players `/at join` -> `/at setup close` -> `/at start`. Everything else is automatic.
For small tests set `tournament.min-players-to-start: 2` (this also gives a smaller bracket).

## Admin commands
- `/at setup [open|close|reopen|build confirm|worldguard]`
- `/at start|pause|resume`, `/at cancel confirm`, `/at reset confirm`
- `/at register <player>`, `/at forcewin <player>`, `/at forfeit <player>`
- `/at seed [add|remove|list|method]`, `/at kit [save|reset|give|mode]`
- `/at arenas [enable|disable <id>]`, `/at validate`, `/at setlobby`, `/at reload`, `/at admin`, `/at history`, `/at player <name>`

Player commands: `/at` (menu), `status`, `join`, `leave`, `bracket`, `matches`, `spectate [player]`.
Permissions: `arenatournament.play` (default true), `arenatournament.admin` (op), `arenatournament.bypass` (op).

## Known design decisions
- A single stadium can host one fight at a time. Semifinals therefore run one after another in the stadium (config `matches.stadium-rounds`). Clear that list to run them in parallel in normal arenas.
- Pause stops new matches from starting. Running matches finish.
- No result is ever guessed after a crash: the tournament comes back PAUSED and interrupted matches restart from WAITING.

## Troubleshooting
- "arenas.yml not loaded": run `/at setup build confirm`.
- An arena reported unavailable: `/at validate` shows the reason. Disable it with `/at arenas disable <id>`.
- A player's inventory is missing after a crash: the saved copy is in the `player_state` table and is restored on their next join.

## Added after the first review pass
- `/at players` (alias `/at list`): everyone can see who registered (with seeds/alive/eliminated once running). Each registration is also announced in chat (`tournament.announce-registrations`).
- `/at replace <old> <new>`: swap in a substitute (registration or between matches); seed and bracket slots move over.
- `/at rematch <player>`: cancel a live match so it restarts from WAITING.
- `/at announce <message>`: broadcast + action bar + sound.
- `prizes:` in config.yml: console commands for the champion and runner-up (disabled by default).
- Scoreboard shows BYE for players resting in round 1.

Not implemented: ready-check before rounds, waitlist, Discord webhook, stats export.
