# Testing report

Automated or manual tests run so far: NONE. The code has never been compiled or run.

## Manual checklist (to run on a Paper 1.21.11 test server; use 2 to 4 accounts or a fake-player tool)
- [ ] Plugin enables, SQLite file created, world auto-builds, `/at validate` all green
- [ ] 24 registrations, duplicate and full-roster rejection, withdraw before start
- [ ] Bracket: 8 byes, 8 R1 matches, R16 pairs each bye seed with an R1 winner
- [ ] 8 matches at once, each in its own arena
- [ ] Death, timeout, disconnect + rejoin inside 30s, disconnect past 30s (forfeit), both disconnect (match replays)
- [ ] Round progression to semifinals, stadium use, champion announcement
- [ ] Inventory/location/xp/gamemode restored after the tournament, after leaving, and after a crash (kill -9 mid-match)
- [ ] Crash recovery: tournament returns PAUSED, `/at resume` continues
- [ ] Spectator GUI, switching matches, return to hub, no interference
- [ ] Duplicate result prevention (`/at forcewin` spam during a death)
- [ ] CRYSTAL and UHC modes: block placement/removal, arena cleanup
- [ ] WorldGuard: `/at setup worldguard`, existing regions unchanged
- [ ] Invalid arena (break a spawn floor): match is not started, admins are notified
